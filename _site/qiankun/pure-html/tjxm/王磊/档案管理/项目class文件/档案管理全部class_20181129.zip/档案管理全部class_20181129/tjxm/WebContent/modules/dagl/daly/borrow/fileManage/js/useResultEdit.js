$(function () {

    var theRequest = GetRequest();
    $("#resId").val(theRequest.resId);
    $("#id").val(regVlaue(theRequest.id));
    $("#opertation").val(theRequest.oper);


    //根据mark获取一个以code、name为键值对的map，用来根据code取对应的字典名称
    /*var map = Dictionary.getNameAndCode({mark: "sb", type: "1"});
    var a = map[1];
    var b = map[2];*/
    var usePurposeMap = "";
    var usePurposeMap = Dictionary.getNameAndCode({mark: "dagl_usePurpose", type: "1"});
    var classificationMap = Dictionary.getNameAndCode({mark: "04", type: "1"});
    var useWayMap = Dictionary.getNameAndCode({mark: "dagl_useWay", type: "1"});

    /**
     * 初始化页面，数据加载、渲染
     */
    if ($("#id").val() != "") {
        var datas1 = {"id": $("#id").val(), "resId": $("#resId").val()};
        //表单数据渲染
        httpRequest("get", "/dagl/daly/borrow/fileEdit", datas1, function (data1) {
            console.log('初始化页面', data1);
            DisplayData.playData({data: data1});
        });
        if ($("#opertation").val() == "VIEW") {
            $("#usePurpose").html(usePurposeMap[$("#usePurpose").text()]);
        }
        $("#usePurpose").html(usePurposeMap[$("#usePurpose").text()]);
        $("#classification").html(classificationMap[$("#classification").text()]);
        $("#useWay").html(useWayMap[$("#useWay").text()]);
    } else {//id为空时，表示新建草稿状态，加载启动节点按钮及启动节点提示信息
       // iniTable();
        //getStartWf();
    }
    //iniFileUpload();
    if($("#useResult").val() != ""){
        $(".commit").hide();
    }
});


/**
 * 提交表单
 * @returns
 */
function commitForm() {
    layer.confirm("确定提交吗？提交后将不能修改！", {
        btn: ['确定', '取消']
    }, function () {
        var flag = saveForm();
        if (flag && flag == "1") {
            layer.msg("提交成功！", {icon: 1});
            //刷新列表
            parent.TableInit.refTable('right_table');
            closeIfram();
            parent.parent.refreshPage("daiban");

        } else if (flag && flag == "2") {

        } else {
            layer.msg("提交失败！", {icon: 2});
        }
    }, function () {
    })
}

//关闭当前窗口
function closeIfram() {
    var index = parent.layer.getFrameIndex(window.name);
    parent.layer.close(index);
}

/**
 * 保存
 */
function saveForm() {
    var res = "";
    var bootstrapValidator = $("#form").data('bootstrapValidator');
    //手动触发验证
    bootstrapValidator.validate();
    if (bootstrapValidator.isValid()) {
        if (!$("#id").val()) {
            $("#subflag").val(Config.startflag);
        }
        $.ajax({
            type: "POST",
            url: "/dagl/daly/borrow/saveUseResult",
            //contentType: "application/json",
            data: $("#form").serialize(),
            // dataType: "json",
            async: false,
            success: function (json) {
                if (json.flag == '1') {
                    res = json.flag;
                    $("#id").val(json.data.id);
                }
            },
            error: function () {
            }
        });
        //保存临时意见
        // var tempIdea = $("#idea").val();
        // saveIdeaTemp($("#workitemid").val(), tempIdea);
    } else {
        res = "2";
    }
    console.log(res);
    return res;
}

/**
 * 空值设置
 * @param val
 * @returns
 */
function regVlaue(val) {
    if (!val) {
        val = "";
    }
    return val;
}




