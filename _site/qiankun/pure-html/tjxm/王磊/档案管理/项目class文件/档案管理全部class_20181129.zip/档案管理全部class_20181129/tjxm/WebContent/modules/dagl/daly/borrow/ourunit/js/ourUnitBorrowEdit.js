$(function () {

    var theRequest = GetRequest();
    $("#resId").val(theRequest.resId);
    $("#id").val(regVlaue(theRequest.id));
    $("#workitemid").val(theRequest.workItemId);
    $("#opertation").val(theRequest.oper);
    $("#renewIds").val(theRequest.renewIds);
    $("#isRenew").val(theRequest.isRenew);
    $("#inRenew").val(theRequest.inRenew);
    //根据mark获取一个以code、name为键值对的map，用来根据code取对应的字典名称
    /*var map = Dictionary.getNameAndCode({mark: "sb", type: "1"});
    var a = map[1];
    var b = map[2];*/
    var usePurposeMap = "";
    if ($("#opertation").val() != "VIEW") {
        //初始化字典项
        /* Dictionary.init({position: "area", mark: "mj", type: "1", name: "area", domType: "checkbox"});
         Dictionary.init({position: "week", mark: "week", type: "1", name: "week", domType: "select"});
         Dictionary.init({position: "sex", mark: "sex", type: "1", name: "sex", domType: "radio"});*/
        //初始化数据字典类型
        Dictionary.init({
            position: "usePurpose",
            mark: "dagl_usePurpose",
            type: "1",
            name: "usePurpose",
            domType: "select"
        });
    } else {
        usePurposeMap = Dictionary.getNameAndCode({mark: "dagl_usePurpose", type: "1"});
    }

    /**
     * 初始化页面，数据加载、渲染
     */
    if ($("#id").val() != "") {

        //表单数据渲染
        var datas = {"id": $("#id").val(), "resId": $("#resId").val()};
        httpRequest("get", "/dagl/daly/borrow/edit", datas, function (data) {
            console.log('初始化页面', data);
            DisplayData.playData({data: data});
            iniTable(data);
            flowTypeChange();
            if (data.data.isChuAdmin != 1) {
                $('#flowType1').attr("disabled", true);
            }
        });
        if ($("#opertation").val() == "VIEW") {
            $("#usePurpose").html(usePurposeMap[$("#usePurpose").text()]);
            if ($("#flowType").text() == '0') {
                $("#flowType").html("借阅本单位");
            } else {
                $("#flowType").html("借阅非本单位");
            }
        }
        //流程相关（按钮、控件等）的渲染
        if ($("#workitemid").val() != "") {
            if ($("#opertation").val() == "EDIT") {
                var datas = {
                    workflowid: $("#workflowid").val(),
                    filetypeid: $("#filetypeid").val(),
                    workitemid: $("#workitemid").val(),
                    pkValue: $("#id").val(),
                    userid: getcookie("userid"),
                    deptid: getcookie("deptid"),
                    oper: $("#opertation").val(),
                    ideaArea: $("ideaArea").val()
                };
                //流转中不可修给表单--开始
                //$('form').find('input,textarea,select').not('#idea').prop('readonly',true);
                //流转中不可修给表单--结束
                //DisplayData.playWorkFlow("/flowService/getFlowData", datas, $("#opertation").val(), callback);
                DisplayData.playWorkFlow("/flowService/getFlowData", datas, $("#opertation").val(), callback, function returnData(data) {
                    var wfleveid = data.flowData.wfleveid;//节点id
                    if ($("#workflowid").val() == "c333a7a057d142308a42f38e8ef74099") {//非本单位
                        /* if (wfleveid == "1542176018148") {//局档案部门
                             $(".isBorrow").show();
                             $("#isBorrowFlag").val("1");
                             $("#nodeFlag").val("1");
                         } else {
                             $(".isBorrow").hide();
                             $("#isBorrowFlag").val("0");
                         }*/
                        if (wfleveid == "1542096270940") {//归档单位领导
                            $("#nodeFlag").val("2");
                        }
                        if (wfleveid == "1542176018148") {//局档案部门
                            $("#nodeFlag").val("1");
                        }
                        if (wfleveid == "1542096270940") {//归档单位领导
                            $("#nodeFlag").val("2");
                            $("#isBorrowFlag").val("1");
                            isBorrowNotDisabled();
                        } else {
                            isBorrowDisabled();
                            $("#isBorrowFlag").val("0");
                        }

                        if (wfleveid != "1542168786645") {
                            $('#usePurpose').attr("disabled", true);
                            $('#email').attr("disabled", true);
                            $('#phone').attr("disabled", true);
                            $('#borrowUserName').attr("disabled", true);
                            $('#unitName').attr("disabled", true);
                            $('#fileUnitName').attr("disabled", true);
                            $(".input-group-addon").attr("onclick", "null");
                            $('#addId').hide();
                            $('#deleteId').hide();
                            fileListDisabled();
                            $('#disabledFlag').val("1");
                            /* $('#flowType1').attr("disabled", true);
                             $('#flowType2').attr("disabled", true);*/
                        }
                    } else {//本单位
                        if (wfleveid == "1542771476814") {//局档案部门
                            $("#nodeFlag").val("1");
                        }
                        if (wfleveid == "1542703756993") {//归档单位领导
                            $("#nodeFlag").val("2");
                            $("#isBorrowFlag").val("1");
                            isBorrowNotDisabled();
                        } else {
                            isBorrowDisabled();
                            $("#isBorrowFlag").val("0");
                        }
                        /* if(wfleveid == "1542703756993"){
                             $(".isBorrow").show();

                         }else{
                             $(".isBorrow").hide();

                         }*/
                        if (wfleveid != "1542711815643") {
                            $('#usePurpose').attr("disabled", true);
                            $('#email').attr("disabled", true);
                            $('#phone').attr("disabled", true);
                            $('#borrowUserName').attr("disabled", true);
                            $('#unitName').attr("disabled", true);
                            $(".input-group-addon").attr("onclick", "null");
                            $('#addId').hide();
                            $('#deleteId').hide();
                            fileListDisabled();
                            $('#disabledFlag').val("1");
                        }

                        if ($("#isRenew").val() == "1") {
                            $('#flowType1').attr("disabled", true);
                            $('#flowType2').attr("disabled", true);
                            $('#borrowUserName').attr("disabled", true);
                            $('#unitName').attr("disabled", true);
                            fileListDisabled();
                        }
                    }
                    var ideaflag = false;
                    var ideaObj = JSON.parse(data.formalIdea);
                    for (var i in ideaObj) {
                        //var ideaObjTemp = JSON.parse(ideaObj[i].ideaList);
                        if (ideaObj[i].ideaList.length > 0) {
                            if (ideaObj[i].name == "dagl_file_unit_leader_idea") {
                                ideaflag = true;
                            }
                        }
                    }
                    if(ideaflag==true){
                        $("#finishButton").val("true");
                    }
                });

            } else {//oper='VIEW'

                var datas = {
                    type: "1",
                    oper: $("#opertation").val(),
                    workitemid: $("#workitemid").val()
                };
                DisplayData.playWorkFlow("/workflow/getYiBanData", datas, $("#opertation").val());
            }
        } else {//workitemid为空时，表示编辑草稿状态，加载启动节点按钮及启动节点提示信息
            if ($("#isRenew").val() == "1") {
                $('#flowType1').attr("disabled", true);
                $('#flowType2').attr("disabled", true);
                $('#borrowUserName').attr("disabled", true);
                $('#unitName').attr("disabled", true);
                fileListDisabled();
            }
            getStartWf();
        }
        if($("#isRenew").val() == "1"){
            $('#flowType1').attr("disabled", true);
            $('#flowType2').attr("disabled", true);
            $('#borrowUserName').attr("disabled", true);
            $('#unitName').attr("disabled", true);
            $('#fileUnitName').attr("disabled", true);
            $(".input-group-addon").attr("onclick", "null");
            fileListDisabled();
        }
    } else {//id为空时，表示新建草稿状态，加载启动节点按钮及启动节点提示信息
        if ($("#renewIds").val() != "") {
            //加载主表和字表的数据，加载完主表的数据后，把主表的id清空
            //
            var datas1 = {"ids": $("#renewIds").val(), "resId": $("#resId").val()};
            httpRequest("get", "/dagl/daly/borrow/renewGetdata", datas1, function (data) {
                console.log('初始化页面', data);
                DisplayData.playData({data: data});
                $("#id").val("");
                $("#subflag").val("0");
                iniTable(data);
                flowTypeChange();
                //某些关键字置灰
                $('#flowType1').attr("disabled", true);
                $('#flowType2').attr("disabled", true);
                $('#borrowUserName').attr("disabled", true);
                $('#unitName').attr("disabled", true);
                $('#fileUnitName').attr("disabled", true);
                $(".input-group-addon").attr("onclick", "null");
                fileListDisabled();
            });
        } else {
            if (getcookie("rolesNo").indexOf("D701") < 0) {
                $('#flowType1').attr("disabled", true);
            }
            flowTypeChange();
            iniTable();
        }
    }
    if ($("#isRenew").val() == '1') {
        $('#addId').hide();
    }
    //iniFileUpload();

    if ($("#subflag").val() != '0') {
        $('#flowType1').attr("disabled", true);
        $('#flowType2').attr("disabled", true);
    } else {
        $('#unitId').val(getcookie("chuShiId"));
        $('#unitName').val(getcookie("chuShiName"));
    }
    if( $('#finishButton').val()=="false"){
        finishButtonVisible();
    }
});

function fileListDisabled() {
    for (var i = 0; i < $("#fileNum").val(); i++) {
        $('#fileCategory' + (i + 1)).attr("disabled", true);
        $('#fileNo' + (i + 1)).attr("disabled", true);
        $('#fileName' + (i + 1)).attr("disabled", true);
        $('#classification' + (i + 1)).attr("disabled", true);
        $('#useWay' + (i + 1)).attr("disabled", true);
    }
}

function isBorrowDisabled() {
    for (var i = 0; i < $("#fileNum").val(); i++) {
        $('#isBorrow' + (i + 1)).attr("disabled", true);
    }
}

function isBorrowNotDisabled() {
    for (var i = 0; i < $("#fileNum").val(); i++) {
        $('#isBorrow' + (i + 1)).attr("disabled", false);
    }
}

function finishButtonVisible() {
   // if ($("#approveUserId").val() == "") {
        $("#noApproval").hide();
        $("#approval").hide();
   // }
}


function iniTable(data) {
    fileList = [{
        id: '',
        fileCategory: '',
        fileNo: '',
        fileName: '',
        fileNum: '',
        classification: '',
        useWay: '',
        isBorrow: '是'
    }];
    if (data != undefined) {
        if (!$.isEmptyObject(data.data.fileList)) {
            fileList = data.data.fileList;
            $("#fileNum").val(data.data.fileList.length);
            if (data.data.fileList.length > 0) {
                $("#approveUserId").val(data.data.fileList[0].approveUserId);
            }
        }
    }

    var html = $('[name=main]').html();
    nodetpl.render(html, {data: fileList}, function (html) {
        $('#otherPeople').find('tbody').empty().append(html);
        for (var i = 0; i < fileList.length; i++) {
            if ($("#opertation").val() != "VIEW") {
                Dictionary.init({
                    position: "useWay" + (i + 1),
                    mark: "dagl_useWay",
                    type: "1",
                    name: "useWay",
                    domType: "select"
                });
                $("#useWay" + (i + 1)).val(fileList[i].useWay);
                Dictionary.init({
                    position: "classification" + (i + 1),
                    mark: "04",
                    type: "1",
                    name: "classification",
                    domType: "select"
                });
                $("#classification" + (i + 1)).val(fileList[i].classification);
                $("#isBorrow" + (i + 1)).val(fileList[i].isBorrow);
            } else {
                var useWayMap = Dictionary.getNameAndCode({mark: "dagl_useWay", type: "1"});
                $("#useWay" + (i + 1)).html(useWayMap[$("#useWay" + (i + 1)).text()]);
                var classificationMap = Dictionary.getNameAndCode({mark: "04", type: "1"});
                $("#classification" + (i + 1)).html(classificationMap[$("#classification" + (i + 1)).text()]);
            }

        }

        // 全选
        var check = new CheckAll('checkboxSuccess', 'checkboxName');
        // 动态增加
        new AddTr({
            'tableId': 'otherPeople',
            'addId': 'addId',
            'deleteId': 'deleteId',
            'numName': 'numName',
            'bottom': 'true',
            'isNumber': 'true',
            'numSort': 'asc',
            'addTrFn': addTabFn,
            "deleteFn": deleteTabFn
        })
    });
}

/**
 * 添加一行
 */
function addTabFn(obj) {
    var subTableLineNum = $("#otherPeople").find("tr").length;
    subTableLineNum++;
    var trCustom = "";
    trCustom += '<tr>';
    trCustom += '<td class="text-center" style="width: 5%"><input type="checkbox" name="checkboxName" value="option1"></td>';
    trCustom += '<td class="text-center" name="numName" style="width: 5%"></td>';
    trCustom += '<td class="text-center" style="width: 8%">';
    trCustom += '	<input type="text" CK_type="ck_required,ck_max" ck_max="50"  CK_info="档案类别"  placeholder="请输入档案类别" class="form-control" id="fileCategory' + subTableLineNum + '" name="fileCategory" />';
    trCustom += '</td>';
    trCustom += '<td class="text-center" style="width: 8%">';
    trCustom += '	<input type="text" CK_type="ck_required,ck_max" ck_max="100"  CK_info="档号"  placeholder="请输入档号" class="form-control" id="fileNo' + subTableLineNum + '" name="fileNo" />';
    trCustom += '</td>';
    trCustom += '<td class="text-center" style="width: 8%">';
    trCustom += '	<input type="text" CK_type="ck_required,ck_max" ck_max="200"  CK_info="档案题名"  placeholder="请输入档案题名" class="form-control" id="fileName' + subTableLineNum + '" name="fileName" />';
    trCustom += '</td>';
    /*trCustom += '<td class="text-center" style="width: 8%">';
    trCustom += '<div class="input-group">';
    trCustom += '	<input type="text" CK_type="ck_required"  CK_info="份数"  placeholder="请输入份数" class="form-control" id="fileNum' + subTableLineNum + '" name="fileNum" />';
    trCustom += '</div>';
    trCustom += '</td>';*/
    trCustom += '<td class="text-center" style="width: 8%">';
    trCustom += '	<select type="text" CK_type="ck_required"  CK_info="密级"  placeholder="请输入密级" class="form-control" id="classification' + subTableLineNum + '" name="classification" >';
    trCustom += getSelect("04", "1");
    trCustom += '</select>';
    trCustom += '</td>';
    trCustom += '<td class="text-center" style="width: 8%">';
    trCustom += '	<select  CK_type="ck_required"  CK_info="利用方式"  placeholder="请输入利用方式" class="form-control" id="useWay' + subTableLineNum + '" name="useWay">';
    trCustom += getSelect("dagl_useWay", "1");
    trCustom += '</select>';
    trCustom += '</td>';

    trCustom += '<td class="text-center" style="width: 8%">';
    trCustom += '	<select disabled class="form-control" id="isBorrow' + subTableLineNum + '" name="isBorrow">';
    trCustom += '<option value="是">是</option>';
    trCustom += '<option value="否">否</option>';
    trCustom += '</select>';
    trCustom += '</td>';
    trCustom += '</tr>';
    return trCustom;
}

function getSelect(mark, type, position) {
    var resId = $("#resId").val();
    var html = "";
    $.ajax({
        type: "get",
        url: "/system/config/dictionary/getListByMark",
        data: {
            "mark": mark,
            "type": type,
            "resId": $("#resId").val()
        },
        dataType: "json",
        async: false,
        success: function (data) {
            if (data.flag == "1") {
                html += "<option data-mark='' value=''>--请选择--</option>";
                $.each(data.data, function (i, n) {
                    if (type == '0') {
                        html += "<option data-mark='" + n.mark + "' value='" + n.code + "'>" + n.name + "</option>";
                    } else if (type == '1') {
                        html += "<option value='" + n.code + "'>" + n.name + "</option>";
                    }
                });
            } else {
                if (data.msg) {
                    layer.msg("获取字典项失败！" + data.msg, {icon: 2});
                } else {
                    layer.msg("获取字典项异常！请刷新重试！", {icon: 2});
                }
            }
        },
        error: function () {
            layer.msg("加载字典项异常！请刷新重试！", {icon: 2});
        }
    })
    return html;
}


/**
 * 删除一行
 */
function deleteTabFn(ids) {
    if ($("#isRenew").val() == "0" || $("#id").val() != "") {
        var resId = $("#resId").val();
        var flag = false;//如果删除成功改为true
        // 删除操作
        $.ajax({
            url: '/dagl/daly/borrow/deleteDaglFile?ids=' + ids + "&resId=" + resId
            , type: "GET"
            , dataType: "json"
            , async: false
            , success: function (result) {
                if (result.flag === "1") {
                    flag = true;
                    parent.TableInit.refTable('right_table');
                    layer.msg("删除成功！", {icon: 1});
                } else {
                    layer.msg("删除失败！", {icon: 2});
                }
            }
            , error: function () {
                layer.msg('删除失败！', {icon: 2});
            }
        });
    } else {
        flag = true;
        parent.TableInit.refTable('right_table');
        layer.msg("删除成功！", {icon: 1});
    }
    return flag;
}

/**
 * 数据字典二级联动
 * 根据省份select初始化城市框
 */

/*function initCity() {
    var shengMark = $("#sheng option:selected").attr("data-mark");
    Dictionary.init({position: "city", mark: shengMark, type: "1", name: "city", domType: "select"});
}*/


/**
 * 提交表单
 * @returns
 */
function commitForm() {
    var flag = saveForm();
    if (flag && flag == "1") {
        if ($("#isRenew").val() == "1"){
            layer.msg("保存成功，如果直接关闭页面，数据会在草稿列表显示！", {icon: 1});
        }else{
            layer.msg("保存成功！", {icon: 1});
        }
        //刷新列表
        parent.TableInit.refTable('right_table');
    } else if (flag && flag == "2") {

    } else {
        layer.msg("保存失败！", {icon: 2});
    }
}

/**
 * 保存
 */
function saveForm() {
    var res = "";
    var checkResult = aotoCheckForm.check($("#otherPeople").find("tr").find("input,select,textarea").not(':hidden'));
    if (checkResult) {
        var bootstrapValidator = $("#form").data('bootstrapValidator');
        //手动触发验证
        bootstrapValidator.validate();
        if (bootstrapValidator.isValid()) {
            var data = getFormData();
            if (!$("#id").val()) {
                $("#subflag").val(Config.startflag);
            }
            $.ajax({
                type: "POST",
                url: "/dagl/daly/borrow/saveForm",
                contentType: "application/json",
                data: JSON.stringify(data),
                dataType: "json",
                async: false,
                success: function (json) {
                    if (json.flag == '1') {
                        res = json.flag;
                        $("#id").val(json.data.id);
                        $("#title").val(json.data.title);
                        $("#subflag").val(json.data.subflag);
                        iniTable(json);
                        finishButtonVisible();
                        if ($('#disabledFlag').val() == "1") {
                            fileListDisabled();
                        }
                        if ($("#isBorrowFlag").val() == "0") {
                            isBorrowDisabled();
                        } else {
                            isBorrowNotDisabled();
                        }
                    }
                },
                error: function () {
                }
            });
            //保存临时意见
            var tempIdea = $("#idea").val();
            saveIdeaTemp($("#workitemid").val(), tempIdea);
        } else {
            res = "2";
        }
    } else {
        res = "2";
    }
    console.log(res);
    return res;
}

function getFormData() {
    var daglBorrow = {
        resId: $('#resId').val(),
        id: $("#id").val(),
        unitId: $("#unitId").val(),
        unitName: $("#unitName").val(),
        borrowUserId: $("#borrowUserId").val(),
        borrowUserName: $("#borrowUserName").val(),
        borrowDeptId: $("#borrowDeptId").val(),
        borrowDeptName: $("#borrowDeptName").val(),
        usePurpose: $("#usePurpose").val(),
        email: $("#email").val(),
        phone: $("#phone").val(),
        title: $("#title").val(),
        fileUnitId: $("#fileUnitId").val(),
        fileUnitName: $("#fileUnitName").val(),
        isRenew: $("#isRenew").val(),
        nodeFlag: $("#nodeFlag").val(),
        flowType: $('#flowType input[name="flowType"]:checked ').val(),
        fileList: new Array()//字表数据
    };//需要提交到后台的数据

    //遍历页面中子表1信息 形成 subTableList
    var $subTableRows = $('#otherPeople').find("tr");//所有子表信息行
    $subTableRows.each(function (i, index) {
        var file = {
            id: $(index).find('[name="id"]').val(),
            fileCategory: $(index).find('[name="fileCategory"]').val(),
            fileNo: $(index).find('[name="fileNo"]').val(),
            fileName: $(index).find('[name="fileName"]').val(),
            fileNum: $(index).find('[name="fileNum"]').val(),
            classification: $(index).find('[name="classification"]').val(),
            useWay: $(index).find('[name="useWay"]').val(),
            isBorrow: $(index).find('[name="isBorrow"]').val(),
            inRenew: $("#inRenew").val(),
            orderNum: i
        }
        daglBorrow.fileList.push(file);
    });
    //以下输出对象deviceInfo 就是完整的请求报文
    return daglBorrow;
}


/**
 * 提交流程
 */
function commitFlow() {
    var flag = saveForm();
    if (flag != "" && flag == "1") {
        var oper = "";
        if ($("#workitemid").val() == "") {
            oper = "NEW";
        } else {
            oper = "EDIT";
        }
        //获取意见
        var idea = $("#idea").val();
        var IsNotionShow = document.getElementById("ideaArea").style.display;
        if (IsNotionShow == "block") {
            if ("2" == document.getElementById("fillmode").value) {
                if (idea == "" || idea == null) {
                    layer.msg("请填写意见！", {icon: 0})
                    return false;
                }
            }
        }
        submitToFlow(oper, this, $("#title").val(), idea, $("#id").val(), "fileUnitId", "attr1", $("#workitemid").val(), $("#workflowid").val());
    } else if (flag && flag == "2") {

    } else {
        layer.msg("数据保存失败！", {icon: 2});
    }
}

function finishFlow(finishFlag) {
    var flag = saveForm();
    completeFlow('', finishFlag);
}

/**
 *  工作流回调该方法，用于改变业务数据状态
 * @param subflag 状态位
 * @returns
 */
function updateBusiData(subflag) {
    $.ajax({
        type: "POST",
        url: "/dagl/daly/borrow/updateFlag",
        data: {
            id: $("#id").val(),
            subflag: subflag
        },
        async: false,
        success: function (data) {
        },
        error: function () {
        }
    });
}

/**
 * 空值设置
 * @param val
 * @returns
 */
function regVlaue(val) {
    if (!val) {
        val = "";
    }
    return val;
}

function flowTypeChange() {
    if ($("#opertation").val() != "VIEW") {
        if ($('#flowType input[name="flowType"]:checked ').val() == "0") {//本单位
            var fileTypeId = "734f44278c21455aba920ab4d3452a95";
            var workFlowId = "734f44278c21455aba920ab4d3452a95";
            $("#filetypeid").val(fileTypeId);
            $("#workflowid").val(workFlowId);
            $(".fileUnit").hide();
        }
        if ($('#flowType input[name="flowType"]:checked ').val() == "1") {//非本单位
            var fileTypeId = "c333a7a057d142308a42f38e8ef74099";
            var workFlowId = "c333a7a057d142308a42f38e8ef74099";
            $("#filetypeid").val(fileTypeId);
            $("#workflowid").val(workFlowId);
            $(".fileUnit").show();
        }
    } else {
        if ($('#flowType').html() == "0") {//本单位
            var fileTypeId = "734f44278c21455aba920ab4d3452a95";
            var workFlowId = "734f44278c21455aba920ab4d3452a95";
            $("#filetypeid").val(fileTypeId);
            $("#workflowid").val(workFlowId);
            $(".fileUnit").hide();
        }
        if ($('#flowType').html() == "1") {//非本单位
            var fileTypeId = "c333a7a057d142308a42f38e8ef74099";
            var workFlowId = "c333a7a057d142308a42f38e8ef74099";
            $("#filetypeid").val(fileTypeId);
            $("#workflowid").val(workFlowId);
            $(".fileUnit").show();
        }
    }

}

