function formValidator(){
	//校验考试基本信息
	$('#form').bootstrapValidator({
        message: 'This value is not valid',
        group:".rowGroup",
        excluded:[":disabled"],
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            title: {
            	trigger:"change",
                validators: {
                    notEmpty: {
                        message: '文件标题不能为空！'
                    },
                    stringLength:{
						max:200,
						message:'文件标题不能超过200字！'
					}
                }
            },
            fileDept: {
				trigger:"change",//监听onchange事件
				validators: {
					notEmpty: {
						message: '来文单位不能为空！'
					},
                    stringLength:{
						max:100,
						message:'来文单位不能超过100字！'
					}
				}
			},
			securityClass: {
				trigger:"change",//监听onchange事件
				validators: {
					notEmpty: {
						message: '密级不能为空！'
					}
				}
			},
			type: {
				trigger:"change",
				validators: {
					notEmpty: {
						message: '文件类型不能为空！'
					}
				}
			},
			createdDate:{
				trigger:"change",
				validators: {
					notEmpty: {
						message: '成文日期不能为空！'
					},
					regexp: {
                        regexp: /^[0-9]+$/,
                        message: '必须是数字，例如：20180521！'
                    }
				}
			},
			quantity:{
				trigger:"change",
				validators: {
					regexp: {
                        regexp: /^[0-9]+$/,
                        message: '必须是数字！'
                    }
				}
			},
			pageNum:{
				trigger:"change",
				validators: {
					regexp: {
                        regexp: /^[0-9]+$/,
                        message: '必须是数字！'
                    }
				}
			},
			fileNum:{
				trigger:"change",
				validators: {
					stringLength:{
						max:100,
						message:'文号不能超过100字！'
					}
				}
			},
			note:{
				trigger:"change",
				validators: {
					stringLength:{
						max:200,
						message:'备注不能超过200字！'
					}
				}
			},
			fileTime:{
				trigger:"change",
				validators: {
					notEmpty: {
						message: '收文日期不能为空！'
					},
					regexp: {
                        regexp: /^[0-9]+$/,
                        message: '必须是数字，例如20180521！'
                    }
				}
			},
			serialNum:{
				trigger:"change",
				validators: {
					stringLength:{
						max:50,
						message:'文件编号不能超过50字！'
					}
				}
			},
			barcode:{
				trigger:"change",
				validators: {
					stringLength:{
						max:30,
						message:'条码编号不能超过30字！'
					}
				}
			},
			zhusUnit:{
				trigger:"change",
				validators: {
					stringLength:{
						max:100,
						message:'主送单位不能超过100字！'
					}
				}
			},
			fileType:{
				trigger:"change",
				validators: {
					stringLength:{
						max:10,
						message:'文种不能超过10字！'
					}
				}
			},
			urgencyDegree:{
				trigger:"change",
				validators: {
					stringLength:{
						max:10,
						message:'紧急程度不能超过10字！'
					}
				}
			},
	        submitHandler: function (validator, form, submitButton) {
	        	alert('submit');
	        }
        }
    });
	
}
