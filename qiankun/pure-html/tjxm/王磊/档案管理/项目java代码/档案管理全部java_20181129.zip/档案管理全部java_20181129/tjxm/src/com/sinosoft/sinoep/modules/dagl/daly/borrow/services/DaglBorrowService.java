package com.sinosoft.sinoep.modules.dagl.daly.borrow.services;

import com.sinosoft.sinoep.common.util.PageImpl;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.entity.DaglBorrow;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.entity.DaglFile;
import com.sinosoft.sinoep.modules.taskplan.entity.TaskPlan;
import com.sinosoft.sinoep.waitNoflow.entity.SysWaitNoflow;
import org.springframework.data.domain.Pageable;

/**
 * @Auther:邴秀慧
 * @Description: 档案借阅服务接口
 * @Date:2018/11/10 9:48
 */
public interface DaglBorrowService {

    /**
     * @Auther:邴秀慧
     * @Description:查询草稿类表
     * @Date:2018/11/10 9:43
     */
    public PageImpl getPageListDraft(Pageable pageable, PageImpl pageImpl, DaglBorrow daglBorrow)  throws Exception;
    /**
     * @Auther:邴秀慧
     * @Description:保存主子表
     * @Date:2018/11/10 9:43
     */
    public DaglBorrow saveForm(DaglBorrow daglBorrow) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:删除主表数据
     * @Date:2018/11/10 10:05
     */
    public int deleteDaglBorrow(String id)  throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:删除字表数据
     * @Date:2018/11/10 10:56
     */
    public int deleteDaglFile(String id) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:获取主子表的数据
     * @Date:2018/11/10 10:57
     */
    public DaglBorrow getById(String id) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:更新subflag的状态值
     * @Date:2018/11/13 20:09
     */
    public DaglBorrow updateSubFlag(String id, String subflag) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:
     * @Date:2018/11/12 15:56
     */
    public PageImpl getAllFileList(Pageable pageable, PageImpl pageImpl, DaglFile daglFile) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:查询文件的对象
     * @Date:2018/11/15 11:14
     */
    public DaglFile fileEdit(String id) throws Exception;
    /**
     * @Auther:邴秀慧
     * @Description:保存应还日期
     * @Date:2018/11/15 11:19
     */
    public DaglFile saveReturnDate(DaglFile daglFile) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:查询正在借阅的列表
     * @Date:2018/11/15 15:18
     */
    public PageImpl getInBorrowList(Pageable pageable, PageImpl pageImpl, DaglFile daglFile) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:借阅历史列表
     * @Date:2018/11/15 18:00
     */
    public PageImpl getRestitutionList(Pageable pageable, PageImpl pageImpl, DaglFile daglFile) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:
     * @Date:2018/11/15 17:56
     */
    public DaglFile saveRevert(String id) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:续借回显查询数据（点击复选框打开的页面的数据）
     * @Date:2018/11/16 9:45
     */
    public DaglBorrow renewGetdata(String ids) throws Exception;

    /**
     * @Auther:邴秀慧
     * @Description:发送消息
     * @Date:2018/11/17 14:57
     */
    public boolean sendMsgsByUid(String userId, String subject, String content, String messageURL, String creTime, SysWaitNoflow entity);

    /**
     * @Auther:邴秀慧
     * @Description:保存利用效果
     * @Date:2018/11/17 14:57
     */
    public DaglFile saveUseResult(DaglFile daglFile) throws Exception;

    public PageImpl getChuInBorrowList(Pageable pageable, PageImpl pageImpl, DaglFile daglFile) throws Exception;

}
