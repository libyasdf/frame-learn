package com.sinosoft.sinoep.modules.dagl.bmgl.services;

import java.util.List;
import java.util.Map;
import com.sinosoft.sinoep.common.util.PageImpl;
import com.sinosoft.sinoep.modules.dagl.bmgl.entity.VirtualClass;

public interface BmglService {
	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO 查询新增动态列表
	 */
	List<Map<String, Object>> dynamicFind(String tName);
	
	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO 动态查询标签
	 */
	List<Map<String, Object>> findLabel(String tName);
	
	/**
	 * 
	 * @param jsonStr
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * int
	 * TODO 动态新增
	 */
	int dynamicAdd(String jsonStr,String tName); 
	
	/**
	 * 
	 * @param jsonStr
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * int
	 * TODO  动态修改
	 */
	int dynamicUpdate(String jsonStr,String tName,String key,String value); 
	
	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO 动态列表
	 */
	List<Map<String, Object>> dynamicList(String tName, PageImpl pageImpl, String jsonStr, String conditions,
			String fids,String parameters,String complexParam,String danweihao);
	
	/**
	 * 
	 * @return
	 * @author 颜振兴
	 * List<VirtualClass>
	 * TODO 获取部门树
	 */
	List<VirtualClass> findTree();
	
	/**
	 * 
	 * @param tName
	 * @param fids
	 * @param column
	 * @param value1
	 * @param value2
	 * @return
	 * @author 颜振兴
	 * int
	 * TODO 替换
	 */
	int replace(String tName,String fids,String column,String value1,String value2);
	
	/**
	 * 
	 * @param tName
	 * @param id
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO 根据recid获取一条数据
	 */
	List<Map<String, Object>> findById(String tName, String id);
	
	/**
	 * 
	 * @param virtualClass
	 * @return
	 * @author 颜振兴
	 * VirtualClass
	 * TODO 添加树节点
	 */
	VirtualClass addTree(VirtualClass virtualClass);
	/**
	 * 
	 * @param id
	 * @return
	 * @author 颜振兴
	 * int
	 * TODO 删除树的节点 包括子节点
	 */
	int deleteTree(String id);
	
	/**
	 * 
	 * @param tName
	 * @param id
	 * @return
	 * @author 颜振兴
	 * int
	 * TODO 动态删除一条数据
	 */
	int dynamicDelete(String tName,String id);
	
	/**
	 * 
	 * @param category_code
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO	根据门类代号查门类id
	 */
	String findMenById(String category_code); 
	
	/**
	 * 
	 * @param category_code_id
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO 根据门类查档号规则
	 */
	List<Map<String, Object>> findDHGZbyMCode(String category_code_id);
	
	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO 根据z表名查询档号关联字段
	 */
	Map<String, Object> findDAGLByTableName(String tName);
	
	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO 根据f表名查询档号关联字段
	 */
	Map<String, Object> findDAGLByTableNameF(String tName);
	
	/**
	 * 
	 * @param tName
	 * @param colnum
	 * @return
	 * @author 颜振兴
	 * String 
	 * TODO 使用英文名查中文名
	 */
	String findZHbycolnum(String tName,String colnum);

	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * List<Map<String,Object>>
	 * TODO 获取档案库标签
	 */
	List<Map<String, Object>> findLabelDAK(String tName);

	/** 
	 * TODO 获取勾选的多行数据列表
	 * @author 李颖洁  
	 * @date 2018年11月22日上午11:27:24
	 * @param tName
	 * @param fids
	 * @return List<Map<String,Object>>
	 */
	List<Map<String, Object>> getSelectedData(String tName, String fids);

	/**
	 * TODO 获取未组卷的文件
	 * @author 李颖洁
	 * @date 2018年11月22日下午1:55:06
	 * @param tName
	 * @return List<Map<String,Object>>
	 */
	List<Map<String, Object>> getNotSetVolumeList(String tName,String basefolderUnit);

	/**
	 * TODO  根据父表id 查询字表的关联信息
	 * @author 李颖洁
	 * @date 2018年11月23日上午11:53:31
	 * @param tName
	 * @param fid
	 * @param basefolderUnit 
	 * @return List<Map<String,Object>>
	 */
	List<Map<String, Object>> getChildDataByFartherId(String tName, String fid, String basefolderUnit);

	/**
	 * TODO 卷内文件从案卷中调出
	 * @author 李颖洁
	 * @date 2018年11月23日下午4:13:10
	 * @param tName 子表表名
	 * @param ids 选中的id
	 * @param archiveFlag  组卷标识
	 * @param conCol 关联字段
	 * @param conVal 关联字段的值
	 * @return int
	 */
	int openVolume(String tName, String ids, String archiveFlag, String conCol, String conVal);

	/**
	 * TODO 更改卷内文件关联（档案确认调整）
	 * @author 李颖洁
	 * @date 2018年11月24日下午6:08:39
	 * @param tName 卷内表名
	 * @param conCol 关联字段
	 * @param conVal 关联字段值
	 * @param data 更改数据项
	 * @return int
	 */
	int updateFileRelation(String tName, String conCol, String conVal, String data,String categoryCode);

	/**
	 * @Author 王富康
	 * @Description //TODO 档案提交
	 * @Date 2018/11/22 19:35
	 * @Param [tName, fids]
	 * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>>
	 **/
	List<Map<String, Object>> recordSubmit(String tName, String fids);
	
	/**
	 * 
	 * @param relevancyId
	 * @param tName
	 * @param chushiId
	 * @return
	 * @author 颜振兴
	 * int
	 * TODO 判断是否在本处下纯在相同管理号 返回>1证明已存在0不存在
	 */
	int isRepetition(String column,String relevancyId,String tName,String chushiId); 
	
	/**
	 * 
	 * @param tName
	 * @param fids
	 * @return
	 * @author 颜振兴
	 * Map<String,Object>
	 * TODO 根据id查数据
	 */
	Map<String, Object> findParentData(String tName,String fids);

	/**
	 * 
	 * @param tName
	 * @param ids
	 * @return
	 * @author 颜振兴
	 * int
	 * TODO 批量删除
	 */
	int dynamicDeletes(String tName, String ids);
	
	/**
	 * 
	 * @param tName
	 * @param chushiid
	 * @return
	 * @author 颜振兴
	 * int
	 * TODO 获取当前处室档案数量
	 */
	int findThisTotal(String tName, String chushiid);
 }
