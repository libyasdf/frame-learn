package com.sinosoft.sinoep.modules.dagl.wdgl.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;

import com.sinosoft.sinoep.modules.dagl.wdgl.entity.DaglConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import com.alibaba.fastjson.JSON;
import com.sinosoft.sinoep.common.util.PageImpl;
import com.sinosoft.sinoep.handlerInterceptor.LogAnnotation;
import com.sinosoft.sinoep.modules.dagl.wdgl.entity.DaglReceiveFile;
import com.sinosoft.sinoep.modules.dagl.wdgl.services.DaglReceiveFileService;
import com.sinosoft.sinoep.modules.dagl.xtpz.datacontrast.entity.ContrastingRelations;
import com.sinosoft.sinoep.user.util.UserUtil;
import net.sf.json.JSONObject;

/**
 * TODO 文电管理控制层（收文）
 * @author 李颖洁  
 * @date 2018年11月10日  下午6:04:09
 */
@Controller
@RequestMapping("/dagl/wdgl/receiveFile")
public class DaglReceiveFileController {
	
	private Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private DaglReceiveFileService fileManageService;
	
	/**
	 * TODO 保存文件信息（收文）
	 * @author 李颖洁  
	 * @date 2018年11月12日上午9:35:14
	 * @param receiveFile
	 * @return JSONObject
	 */
	@LogAnnotation(value = "save",opName = "保存文件信息")
	@ResponseBody
	@RequestMapping(value="save",method=RequestMethod.POST)
	public JSONObject saveReceiveFile(DaglReceiveFile receiveFile){
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			receiveFile = fileManageService.editReceiveFile(receiveFile);
			json.put("flag", "1");
			json.put("data", receiveFile);
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			json.put("msg", "保存数据失败！");
		}
		return json;
	} 
	
	/**
	 * TODO 修改文件信息（收文）
	 * @author 李颖洁  
	 * @date 2018年11月12日上午11:10:00
	 * @param receiveFile
	 * @return JSONObject
	 */
	@LogAnnotation(value = "edit",opName = "修改文件信息")
	@ResponseBody
	@RequestMapping(value="edit")
	public JSONObject editReceiveFile(DaglReceiveFile receiveFile ){
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			//根据id 获取文件信息
			receiveFile = fileManageService.getOne(receiveFile);
			json.put("flag", "1");
			json.put("data", receiveFile);
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
		return json;
	} 
	
	/**
	 * TODO 删除文件信息（单个）（收文）
	 * @author 李颖洁  
	 * @date 2018年11月12日上午11:25:09
	 * @param receiveFile
	 * @return JSONObject
	 */
	@LogAnnotation(value = "delete",opName = "删除单个数据")
	@ResponseBody
	@RequestMapping("delete")
	public JSONObject deleteOne(DaglReceiveFile receiveFile){
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			//删除一个文件
			int result = fileManageService.deleteOne(receiveFile);
			if(result>0){
				json.put("flag", "1");
				json.put("msg", "删除成功！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(),e);
			json.put("msg", e.getMessage());
		}
		return json;
	}
	
	/**
	 * TODO 删除文件信息（批量）（收文）
	 * @author 李颖洁  
	 * @date 2018年11月12日上午11:25:09
	 * @param receiveFile
	 * @return JSONObject
	 */
	@LogAnnotation(value = "batchDelete",opName = "批量删除数据")
	@ResponseBody
	@RequestMapping("batchDelete")
	public JSONObject deletePlan(String ids){
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			//删除多个文件
			int result = fileManageService.batchDelete(ids);
			if(result>0){
				json.put("flag", "1");
				json.put("msg", "删除成功！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(),e);
			json.put("msg", e.getMessage());
		}
		return json;
	}
	
	/**
	 * TODO 获取文件信息列表，带分页（收文）
	 * @author 李颖洁  
	 * @date 2018年11月12日下午2:07:06
	 * @param pageImpl
	 * @param receiveFile
	 * @return PageImpl
	 */
	@LogAnnotation(value = "query",opName = "查询文件数据列表")
	@ResponseBody
	@RequestMapping("getList")
	public PageImpl getFileList(PageImpl pageImpl,DaglReceiveFile receiveFile) {
		pageImpl.setFlag("0");
		try {
			
			Pageable pageable = new PageRequest(pageImpl.getPageNumber()-1, pageImpl.getPageSize());
			receiveFile.setCreChushiId(UserUtil.getCruChushiId());
			Page<DaglReceiveFile> page = fileManageService.list(receiveFile, pageImpl,pageable);
			pageImpl.setFlag("1");
			pageImpl.getData().setRows(page.getContent());
			pageImpl.getData().setTotal((int)page.getTotalElements());
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(),e);
		}
		return pageImpl;
	}
	
    /**
     * TODO 导入数据（收文）
     * @author 李颖洁  
     * @date 2018年11月16日下午2:09:35
     * @param request
     * @param fileToUpload
     * @return JSONObject
     */
    @RequestMapping(value = "/importInfo",method = RequestMethod.POST)
    @ResponseBody
    public JSONObject importInfo(HttpServletRequest request, @RequestParam("file") MultipartFile fileToUpload){
        String filePath = request.getSession().getServletContext().getRealPath("/")+"upload"+fileToUpload.getOriginalFilename();
        JSONObject json = new JSONObject();
        String msg = "导入成功！";
        try {
            msg = fileManageService.importInfo(filePath,fileToUpload);
        } catch (Exception e) {
            msg = "导入失败！";
            e.printStackTrace();
            log.error(e.getMessage(),e);
        }

        json.put("msg",msg);
        return json;
    }

    /**
	 * TODO 归档文件操作（收文）
	 * @author 李颖洁  
	 * @date 2018年11月12日上午9:35:14
	 * @param receiveFile
	 * @return JSONObject
	 */
	@LogAnnotation(value = "save",opName = "文件归档")
	@ResponseBody
	@RequestMapping(value="/tidyRecode")
	public JSONObject tidyRecode(ContrastingRelations relations,@RequestParam("data")String data){
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			List<DaglReceiveFile> listData = JSON.parseArray(data,DaglReceiveFile.class);
			String ids = "";
			for (DaglReceiveFile daglReceiveFile : listData) {
				ids += "'"+daglReceiveFile.getId()+"',";
			}
			ids = ids.substring(0,ids.length()-1);
			if(ids.length()>0){
				int flag = fileManageService.tidyRecode(relations,ids);
				if(flag==0){
					json.put("msg", "归档失败！");
				}else{
					int num = fileManageService.updateState(ids);
					if(num>0){
						json.put("flag", "1");
					}else{
						json.put("msg", "归档失败！");
					}
				}
			}else{
				json.put("msg", "请选择数据！");
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			json.put("msg", "归档失败！");
		}
		return json;
	}

	/**
	 * TODO 扫码枪配置（收文）
	 * @author 张浩磊
	 * @date 2018年11月12日上午9:35:14
	 * @param receiveFile
	 * @return JSONObject
	 */
	@LogAnnotation(value = "save",opName = "保存文件信息")
	@ResponseBody
	@RequestMapping(value="saveConfig",method=RequestMethod.POST)
	public JSONObject saveConfig(DaglConfig daglConfig){
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			daglConfig = fileManageService.saveConfig(daglConfig);
			json.put("flag", "1");
			json.put("data", daglConfig);
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			json.put("msg", "保存数据失败！");
		}
		return json;
	}

	/**
	 * TODO 获取扫码枪配置信息
	 * @author 李颖洁
	 * @date 2018年11月12日上午11:10:00
	 * @param receiveFile
	 * @return JSONObject
	 */
	@LogAnnotation(value = "query",opName = "获取扫码枪配置信息")
	@ResponseBody
	@RequestMapping(value="editConfig")
	public JSONObject editConfig(DaglConfig daglConfig){
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			//根据id 获取文件信息
			daglConfig = fileManageService.getConfig(daglConfig);
			json.put("flag", "1");
			json.put("data", daglConfig);
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
		return json;
	}
}
