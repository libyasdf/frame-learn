
$(function() {
    var locator =new ActiveXObject ("WbemScripting.SWbemLocator");
    var service = locator.ConnectServer(".");
    var properties = service.ExecQuery("Select * from Win32_NetworkAdapterConfiguration Where IPEnabled =True");
    var e =new Enumerator (properties);
    var p = e.item();
    var mac = p.MACAddress;
    getConfig(mac);
});

function getConfig(mac){
    $.ajax({
        type: "POST",
        url:"/dagl/wdgl/receiveFile/editConfig",
        data:{id:mac},
        async:false,
        success:function(json){
            if(json.flag == 1){
                $("#comName").val(json.data.comId);
            }
        },
        error:function(){
        }
    });
}

//重写mscomm控件的唯一事件处理代码
function MSComm1_OnComm() {
    var len = 0;
    if (MSComm1.CommEvent == 1)//如果是发送事件
    {
        window.alert("ok");//这句正常，说明发送成功了
    }
    else if (MSComm1.CommEvent == 2)//如果是接收事件
    {
        var result = MSComm1.Input;
        //输出扫描到的条码信息
        var sts = result.split("^");
        setEntity(sts);
    }

    return false;
}

function OpenPort() {
    if($("#comName").val() == null || $("#comName").val() == ""){
        layer.alert("系统没有检测到串口，请到基础配置模块配置后再试！", {icon: 5});
        return false;
    }else{
        MSComm1.CommPort = $("#comName").val();
    }
    if (MSComm1.PortOpen == false) {
        MSComm1.PortOpen = true;
        $("#open").css("display","none");
        $("#close").css("display","inline");
        layer.alert("扫描枪连接成功!");
    }else if(typeof(MSComm1.PortOpen) == "undefined" || MSComm1.PortOpen == null){
        layer.alert("请安装控件后再试！", {icon: 5})
    } else {
        layer.alert("已经开始接收数据!");
    }
}

function ClosePort() {
    if (MSComm1.PortOpen == true) {
        MSComm1.PortOpen = false;
        $("#open").css("display","inline");
        $("#close").css("display","none");
        layer.alert("已断开连接!");
    }
    else {
        window.alert("串口已经关闭!");
    }
}






