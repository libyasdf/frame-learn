package com.sinosoft.sinoep.modules.dagl.wdgl.dao;

import com.sinosoft.sinoep.common.jpa.repository.BaseRepository;
import com.sinosoft.sinoep.modules.dagl.wdgl.entity.DaglConfig;

public interface DaglConfigDao extends BaseRepository<DaglConfig, String>{
	
	
}
