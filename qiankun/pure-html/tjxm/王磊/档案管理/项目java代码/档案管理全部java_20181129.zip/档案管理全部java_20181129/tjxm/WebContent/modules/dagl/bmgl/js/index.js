// 全局变量
var tHeadData; // 表头标签
var tabCurrent; // 记录是哪个当前标签页
var tabData = []; // 记录所有标签页的信息
var checkBoxData = {}; // 选中的复选框的信息
var nodes = null; // 树节点
var easyQueryP = ""//简单查询的参数
var complexQueryP = ""//组合查询参数
var index;
var parameter;
var num = 1;//显示第几页
var ud = 0;// window.scrollTop;判断上下滚动
var lr = 0; //= window.scrollLeft;判断左右滚动
var select_no={};//字典名称和mark值
var treeindex;//关闭加载框用到
var dataZiDian={};//所有的字典值
var danweiindex;//单位查询加载标签
// 页面加载完成
$(function () {
    var url = $("#left_ul").find("a.active").attr("url");

    parameter = new GetParameter(url);
    // 初始化页面
    initPage();
  //当前用户的角色编号
	var rolesNo = getcookie("rolesNo");
	if(rolesNo.indexOf("D702")>-1){
		$("#rolesNo").show();
	}
});

/**
 * 初始化页面
 */
function initPage() {

    // 添加载动画
    index = layer.msg('加载中，请稍等...', {
        icon: 16,
        shade: [0.1, '#fff'],
        time: false
    });

    // 删除 layer.js 额外引用的 link 标签
    $('#layuicss-layer').remove();

    // 初始化左侧树
    typeTree.init({});
    nodes = $.fn.zTree.getZTreeObj("treeDemo").getSelectedNodes();

    // 解除绑定方法
    $('.dropdown-menu .dropdown-item').unbind();

    // 初始化标签
    initTabs();

    // 事件绑定可以放在下面
    $('.dropdown-menu .dropdown-item:contains(新增)').click(newlyAdded);
    $('.dropdown-menu .dropdown-item:contains(替换)').click(replacelyAdded);
    $('.dropdown-menu .dropdown-item:contains(简单查询)').click(easyFind);
    $('.dropdown-menu .dropdown-item:contains(档案调整)').click(adjust);
    $('.dropdown-menu .dropdown-item:contains(q2变更)').click(qTwo);
    $('.dropdown-menu .dropdown-item:contains(组合查询)').click(complexFind);
    $('.dropdown-menu .dropdown-item:contains(移交)').click(submitData);
    $('.dropdown-menu .dropdown-item:contains(删除)').click(dels);
}

/**
 * 加载标签页
 */
function initTabs() {
    var LableUrl = "";
    if (parameter.dak == "null") {
        LableUrl = "/dagl/bmgl/findLabel";
    } else if (parameter.dak == "dak") {
        LableUrl = "/dagl/bmgl/findLabelDAK"
    }
    nodes = $.fn.zTree.getZTreeObj("treeDemo").getSelectedNodes();
    $.ajax({
        url: LableUrl,
        data: {
            tName: nodes[0].categoryCode
        },
        type: 'get',
        dataType: 'json',
        async: true,
        success: function (data) {
            // 清空标签
            $('.tab-container .tab').remove();

            // 解析 data
            var data = data;
            console.log("加载标签页的数据：\n", data);

            // 加载标签
            for (let i = 0; i < data.length; ++i) {
                $('.select-container').before($(''
                    + '<div class="tab" data-TABLE_NAME="' + data[i].TABLE_NAME + '">'
                    + data[i].TABLE_CHN_NAME
                    + '</div>')
                );

                // 初始化 tabData
                tabData.push(data[i].TABLE_NAME);

                // 初始化 checkBoxData
                checkBoxData[data[i].TABLE_NAME] = [];
            }

            // 激活第一个标签
            $('.tab-container .tab:eq(0)').addClass('tab-active');
            tabCurrent = $('.tab-container .tab:eq(0)').attr('data-TABLE_NAME');

            // 初始化面板
            initPanel();
        },
        error: function (err) {
            layer.msg('加载失败，请刷新页面');
            console.log("加载标签页失败，错误信息：\n", err);
        }
    });
}

/**
 * 切换标签页
 */
var index2;
function switchTab() {

    // 解绑 click 事件
    $('.tab-container .tab').unbind('click');

    // 添加载动画
    index2 = layer.msg('加载中，请稍等...', {
        icon: 16,
        shade: [0.1, '#fff'],
        time: false
    });

    // 切换激活状态
    $('.tab-container .tab').removeClass('tab-active');
    $(this).addClass('tab-active');

    // 修改 tabCurrent
    tabCurrent = $(this).attr('data-TABLE_NAME');

    // 修改 checkBoxData
    var index = $(this).index();
    for (let i = index; i < tabData.length; ++i) {
        checkBoxData[tabData[i]] = [];
    }

    console.log("点击标签页后的tabCurrent", tabCurrent);
    console.log("点击标签页后的checkboxData", checkBoxData);

    // 初始化面板
    initPanel();
}

function easyQuery(pm) {
    easyQueryP = pm;
    initPanel();
}

/**
 * 初始化面板
 */
function initPanel() {
    num = 1;

    nodes = $.fn.zTree.getZTreeObj("treeDemo").getSelectedNodes();
    // 删除旧的面板，新建新的面板
    $('.tab-panel').remove();
    $('.total').remove();
    $('.tab-panel-container').append($('<div class="tab-panel"></div><div class="total" style="margin-top:-27px;margin-left:63%;font-size:17px ">当前总条数为：<span style="font-size:17px" id="total"></span>条</div>'));

    // 添加表格
    $('.tab-panel').append($(''
        + '<table id="table" class="table table-bordered table-striped table-hover table-condensed table-responsive">'
        + '<thead>'
        + '<tr></tr>'
        + '</thead>'
        + '<tbody id="tbody"></tbody>'
        + '</table>')
    );

    // 加载表头
    initTableHead();

    /**
     * 滚轮到底加载
     * @returns
     */
    $('#tbody').bind('scroll', function () {
        if ($('#tbody').scrollTop() != ud) {
            ud = $('#tbody').scrollTop();
            if ($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
                num++;
                initTableBody(num)
            }
        }
        if ($('#tbody').scrollLeft() != lr) {

        }

    });
}

/**
 * 加载表头
 */
function initTableHead() {

    $.ajax({
        url: "/dagl/bmgl/findAdd",
        data: {
            tName: tabCurrent // 表名
        },
        type: "post",
        dataType: 'json',
        success: function (data) {

            // 获取数据，并根据 COLUMN_ORDER 字段进行排序
            var data = data.sort(sortByNumber('COLUMN_ORDER'));
            console.log("加载表头的数据\n", data);

            // 给全局变量赋值
            tHeadData = data;
           // var marks=[];
            // 加载表头
            for (let i = 0; i < data.length; ++i) {
            	if(data[i].COLUMN_INPUT_TYPE=="S"){
            		if(data[i].COLUMN_NAME!="basefolder_unit"){
            			select_no[data[i].COLUMN_NAME]=data[i].COLUMN_SELECT_NO;
            			//marks.push(data[i].COLUMN_SELECT_NO);
            		}
            	}
                if (data[i].COLUMN_AS_SIMQUERY === "T") {
                    $('table thead tr').append($('<th>' + data[i].COLUMN_CHN_NAME + '</th>'));
                }
            }
            // 添加复选框和操作
            $('table thead tr').prepend($('<th style="text-align: center;"><input type="checkbox" id="all" ></th>'));
            $('table thead tr').append($('<th>操作</th>'));
            $("#all").click(all)
            //findAllZiDian(marks.toString())//查数据字典的内容
            // 加载表格内容
            initTableBody(1);

        },
        error: function (err) {
            layer.msg('加载失败，请刷新页面');
            console.log("加载表头失败，错误信息：\n", err);
        }
    });
}

//查数据字典的内容
function findAllZiDian(MS){
	$.ajax({
		url:"/dagl/bmgl/byDataDictionary",
		data:{marks:MS},
		type: "post",
        dataType: 'json',
        async:false,
        success: function (data) {
        	dataZiDian=data;
        	console.log("数据字典："+dataZiDian)
        }
		
	})
}

//递归获得树节点字段值
function getKeyValue(obj, treeObj) {
    if (treeObj == null) {
        return "";
    }

    if (treeObj.pId != "" && treeObj.pId != null) {
        var filename = treeObj.columnName;
        obj[filename] = treeObj.columnValue;
    } else {
        //obj.categoryCode=treeObj.categoryCode;
    }
    var pNode = treeObj.getParentNode();
    if (pNode != null) {
        getKeyValue(obj, pNode);
    }
}


/**
 * 获取系统唯一关键字
 * @return {String} 加载表格内容所需的 fids 参数
 */
function getFids() {

    // 获取当前激活标签的索引
    var index = $('.tab-active').index();

    if (index === 0) {
        return "";
    }
    return checkBoxData[tabData[index - 1]].toString();
}
/**
 * 加载表格内容
 */
function initTableBody(pageNumber) {



    function getTree() {
        var object = {};
        getKeyValue(object, nodes[0]);
        return JSON.stringify(object);
    }

    $.ajax({
        url: '/dagl/bmgl/dynamicList',
        data: {
            tName: tabCurrent, // 表名
            fids: getFids(), // 系统唯一关键字
            conditions: getTree(), // 树的节点条件
            pageNumber: pageNumber, // 页码
            pageSize: "20", // 每页显示数据条数
            parameters: easyQueryP,
            complexParam:complexQueryP,
            danweihao:$("#danweihao").val()
        },
        type: 'post',
        dataType: 'json',
        success: function (data) {
            // 解析数据
            var data = data;
            console.log("加载列表内容的数据", data);
            if(data.length==1){
            	 if (data.length-1 <= 0) {
 	                if (pageNumber > 1) {
 	                    layer.msg("已拉到最底");
 	                    return;
 	                } else {
 	                    layer.msg("暂无数据");
 	                    $("#total").html("0");
 	                }
 	            }
            }else{
	            if (data.length <= 0) {
	                if (pageNumber > 1) {
	                    layer.msg("已拉到最底");
	                    return;
	                } else {
	                    layer.msg("暂无数据");
	                    $("#total").html("0");
	                }
	            }
            }
            // 加载表格内容
            for (let i = 0; i < data.length; ++i) {
            	if( data.length==1){
            		 $("#sqlStr").val(data[i].sqlStr);
            		 break;
            	}
            	if(Object.keys(data[i])[0]=="total"||Object.keys(data[i])[0]=="sqlStr"){
            		 $("#total").html(data[i].total);
            		 $("#sqlStr").val(data[i].sqlStr);
            		 continue;
            	}
                // 渲染表格内容
                var $tr = $('<tr></tr>')
                $('.tab-panel table tbody').append($tr);
                for (let j = 0; j < tHeadData.length; ++j) {
                    if (tHeadData[j].COLUMN_AS_SIMQUERY === 'T') {
                        var keyStr = tHeadData[j].COLUMN_NAME.toUpperCase('utf8');
                        var valueStr=data[i][keyStr] ? data[i][keyStr] : '';
                        var keyStrMin=keyStr.toLowerCase();
// 以下部分用于下拉菜单中 用code查name的内容                        
//                        if(JSON.stringify(select_no).indexOf(keyStrMin)>-1){
//                        	if(valueStr!=null&&valueStr!=''){
//	                        	var mark=select_no[keyStrMin];
//	                        	//var map=Dictionary.getNameAndCode({mark:mark,type:"1"});
//	                        	/*console.log("key"+keyStrMin);
//	                        	console.log("marl"+mark);
//	                        	console.log("map"+JSON.stringify(map));
//	                        	console.log("value"+valueStr);*/
//	                        	//console.log(dataZiDian)
//	                        	//console.log(dataZiDian[mark])
//	                        	valueStr=dataZiDian[mark][valueStr]
//	                        	
//	                        	if(typeof(valueStr)=="undefinde"||valueStr==null||valueStr==""){
//	                        		valueStr="";
//	                        	}
//                        	}else{
//                        		valueStr=" ";
//                        	}
//                        }
//                        if(keyStrMin=="basefolder_unit"){
//                        	//valueStr=data[i].CRE_CHUSHI_NAME;
//                        	if(valueStr==null||valueStr==''){
//                        		valueStr='';
//                        	}
//                        }
                        $tr.append($('<td title='+valueStr+'> '+ (valueStr.length >= 8?valueStr.substring(0,8)+'...':valueStr) + '</td>'));
                    }
                }

                // 添加复选框和操作按钮
                var ed = JSON.stringify(checkBoxData).indexOf(data[i].RECID) > -1 ? "checked" : "";
                console.log(ed);
                $tr.prepend($('<td class="text-center"><input type="checkbox" value="' + data[i].RECID + '" ' + ed + '></td>'));
                $tr.append($(''
                    + '<td>'
                    + '<i class="glyphicon glyphicon-edit opreation"></i>'
                    + '<i class="glyphicon glyphicon-trash opreation"></i>'
                    + '</td>')
                );

                // 给复选框绑定方法
                $tr.find('td input[type="checkbox"]').change(changeCheckBoxState).click(stopBubble);

                // 给操作按钮绑定方法
                $tr.find('.glyphicon-edit').click(modify);

                // 给操作按钮绑定方法
                $tr.find('.glyphicon-trash').click(del);

                // 打开只读页
                $tr.click(readOnly);
            }

            // 给表格绑定滚动条方法让表头列表一起滚动
            $('.tab-panel-container .tab-panel table').scroll(function () {
                var scrollDisplacement = $(this).scrollLeft();
                $(this).find('thead').scrollLeft(scrollDisplacement);
                $(this).find('tbody').scrollLeft(scrollDisplacement).css('left', scrollDisplacement + 'px');
            });
            // 给标签绑定事件
            $('.tab-container .tab').unbind('click');
            $('.tab-container .tab').click(switchTab);

            // 关闭加载动画
            layer.close(index);
            layer.close(index2);
            layer.close(treeindex);
            layer.close(danweiindex);

            ud = $("#tbody").scrollTop();
            lr = $("#tbody").scrollLeft();
        },
        error: function (err) {
            layer.close(index);
            layer.close(index2);
            layer.close(treeindex);
            layer.close(danweiindex);
            layer.msg("页面出现异常，请尝试刷新页面，再次操作")
        }
    });
}

// 阻止事件冒泡
function stopBubble() {
    window.event ? window.event.cancelBubble = true : event.stopPropagation();
}
/**
 * 单位提交按钮事件
 * @returns
 */
function danweiE(){
    // 添加载动画
    danweiindex = layer.msg('加载中，请稍等...', {
        icon: 16,
        shade: [0.1, '#fff'],
        time: false
    });
    initPanel();
}


/**
 * 改变复选框状态
 */
function changeCheckBoxState() {

    // 当前激活的标签页
    var tabName = $('.tab-active').attr('data-TABLE_NAME');

    // 给全局变量增加或删除复选框 fid
    if ($(this).prop('checked') === true || $(this).prop('checked') === 'checked') {
        checkBoxData[tabName].push($(this).val());
        console.log("添加复选框数据", checkBoxData[tabName]);
    } else {
        checkBoxData[tabName].removeItem($(this).val());
        console.log("删除复选框数据", checkBoxData[tabName]);
    }
}

/**
 * 新增操作
 */
function newlyAdded() {
    layer.open({
        type: 2,
        title: '新增',
        content: '/modules/dagl/bmgl/form.html?categoryCode=' + $.fn.zTree.getZTreeObj("treeDemo").getSelectedNodes()[0].categoryCode+"&fids="+getFids(),
        area: ['1100px', 'auto'],
        offset: '30px',
        resize: false,
        maxmin: true,
        success: function (layero, index) {

        },
        full: function (layero) {

            // 让 iframe 高度自适应
            layero.find('iframe').css('max-height', 'none');
        },
        restore: function (layero) {

            // 让 iframe 最高高度为 600px
            layero.find('iframe').css('max-height', '600px');
        },
        end: function () {

            // 点击当前激活的标签页来刷新当前列表内容
            $('.tab-active').trigger('click');
        }
    });
}

/**
 * 批量删除操作
 * @returns
 */
function dels(event) {
	if(checkBoxData[tabCurrent].toString()==""){
		layer.msg("至少需要选择一条数据！")
		return;
	}
    layer.confirm("确定要删除所选择的条数据吗？", { icon: 3 }, function () {
        $.ajax({
            type: "POST",
            url: "/dagl/bmgl/dynamicDeletes",
            data: {
                ids: checkBoxData[tabCurrent].toString(),
                tName: tabCurrent
            },
            dataType: "json",
            success: function (data) {
                if ('1' == data.flag) {
                    layer.msg(data.total+"条记录删除成功！", {
                        icon: 1,
                        time: 1000
                    }, function (index) {
                        initPanel();
                    });
                } else {
                    layer.msg("删除失败，请刷新页面再次操作", {
                        icon: 5
                    });
                }
            },
            error: function (data) {
            }
        });
    });
}

/**
 * 删除操作
 * @returns
 */
function del(event) {

    // 阻止事件冒泡
    window.event ? window.event.cancelBubble = true : event.stopPropagation();

    var rid = $(this).parent().parent().find("td").eq(0).find("input").val();
    layer.confirm("确定要删除该条数据吗？", { icon: 3 }, function () {
        $.ajax({
            type: "POST",
            url: "/dagl/bmgl/dynamicDelete",
            data: {
                id: rid,
                tName: tabCurrent
            },
            dataType: "json",
            success: function (data) {
                if ('1' == data.flag) {
                    layer.msg("删除成功！", {
                        icon: 1,
                        time: 1000
                    }, function (index) {
                        initPanel();
                    });
                } else {
                    layer.msg("删除失败，请刷新页面再次操作", {
                        icon: 5
                    });
                }
            },
            error: function (data) {
            }
        });
    });
}

/**
 * 打开只读页
 */
function readOnly() {
	
	var $this = $(this);
	
    // 添加修改标识
    $this.addClass('readonly');

    console.log("操作按钮", $this);

    // 打开修改弹框
    layer.open({
        type: 2,
        title: '预览',
        content: '/modules/dagl/bmgl/readonly.html',
        area: ['800px', 'auto'],
        offset: '30px',
        resize: false,
        maxmin: true,
        success: function (layero, index) {

        },
        full: function (layero) {

            // 让 iframe 高度自适应
            layero.find('iframe').css('max-height', 'none');
        },
        restore: function (layero) {

            // 让 iframe 最高高度为 600px
            layero.find('iframe').css('max-height', '600px');
        },
        end: function () {

        	// 去掉 tr 的 readonly 类
        	$this.removeClass('readonly');
        	
            // 点击当前激活的标签页来刷新当前列表内容
        	// $('.tab-active').trigger('click');
        }
    });
}

/**
 * 修改操作
 */
function modify(event) {

    // 阻止事件冒泡
    window.event ? window.event.cancelBubble = true : event.stopPropagation();

    // 添加修改标识
    $(this).addClass('modify');

    console.log("操作按钮", $(this));

    // 打开修改弹框
    layer.open({
        type: 2,
        title: '修改',
        content: '/modules/dagl/bmgl/modify.html?categoryCode=' + $.fn.zTree.getZTreeObj("treeDemo").getSelectedNodes()[0].categoryCode,
        area: ['1100px', 'auto'],
        offset: '30px',
        resize: false,
        maxmin: true,
        success: function (layero, index) {

        },
        full: function (layero) {

            // 让 iframe 高度自适应
            layero.find('iframe').css('max-height', 'none');
        },
        restore: function (layero) {

            // 让 iframe 最高高度为 600px
            layero.find('iframe').css('max-height', '600px');
        },
        end: function () {

            // 点击当前激活的标签页来刷新当前列表内容
            $('.tab-active').trigger('click');
        }
    });
}

/**
 * 替换操作
 */
function replacelyAdded() {
    if (checkBoxData[tabCurrent].length < 1) {
        layer.msg("请选择需要替换的项在点击替换按钮")
        return;
    }
    layer.open({
        type: 2,
        title: '替换',
        content: '/modules/dagl/bmgl/replace.html?fids=' + checkBoxData[tabCurrent].toString() + "&tName=" + tabCurrent + "&categoryCode=" + nodes[0].categoryCode,
        area: ['700px', '350px'],
        offset: '100px',
        resize: false,
        maxmin: true,
        success: function (layero, index) {
            // layer.iframeAuto(index);
        },
        full: function (layero) {

            // 让 iframe 高度自适应
            layero.find('iframe').css('max-height', '500px');
        },
        restore: function (layero) {

            // 让 iframe 最高高度为 500px
            layero.find('iframe').css('max-height', '500px');
        }
    });
}
var indexx;
function max() {
    layer.full(indexx);
}

/**
 * 简单查询
 */
function easyFind() {
    $('.tab-container .tab').unbind('click');
    layer.open({
        type: 2,
        title: '简单查询',
        content: '/modules/dagl/bmgl/easyFind.html?tName=' + tabCurrent,
        area: ['300px', '500px'],
        offset: 'lb',
        resize: false,
        maxmin: true,
        shade: 0,
        success: function (layero, index) {
            // layer.iframeAuto(index);
            indexx = index;
        },
        full: function (layero) {

            // 让 iframe 高度自适应
           // layero.find('iframe').css('max-height', '500px');
        	layero.find("iframe").css('max-height', '800px');
        },
        restore: function (layero) {

            // 让 iframe 最高高度为 500px
        	 layero.find("iframe").css('max-height', '454px');
            layero.css({'height':'500px','width':'300px','top':'calc(100% - 500px)'});
        },
        end: function () {
            easyQuery("");
            //complexQuery("");
            //$('.tab-container .tab').click(switchTab);
        }
    });
}


function adjust() {
   // $('.tab-container .tab').unbind('click');
    layer.open({
        type: 2,
        title: '档案调整',
        content: '/modules/dagl/bmgl/adjust.html?tName=' + tabCurrent + '&fids=' + checkBoxData[tabCurrent].toString()+ "&categoryCode=" + nodes[0].categoryCode,
        area: ['1500px', '780px'],
        offset: '50px',
        resize: false,
        maxmin: true,
        success: function (layero, index) {
            // layer.iframeAuto(index);
            indexx = index;
        },
        full: function (layero) {

            // 让 iframe 高度自适应
            layero.find('iframe').css('max-height', '500px');
        },
        restore: function (layero) {

            // 让 iframe 最高高度为 500px
            layero.find('iframe').css('max-height', '500px');
        },
        end: function () {
            //easyQuery("");
            //complexQuery("");
            //$('.tab-container .tab').click(switchTab);
        }
    });
}

function qTwo() {
  //  $('.tab-container .tab').unbind('click');
	if(checkBoxData[tabCurrent].toString()==""){
		layer.msg("至少需要选择一条数据！")
		return;
	}
    layer.open({
        type: 2,
        title: 'q2变更',
        content: '/modules/dagl/daly/qtwo/Q2EditForm.html?tName=' + tabCurrent + '&ids=' + checkBoxData[tabCurrent].toString(),
        area: ['1200px', '600px'],
        offset: '20px',
        resize: false,
        maxmin: true,
        success: function (layero, index) {
            // layer.iframeAuto(index);
            indexx = index;
        },
        full: function (layero) {

            // 让 iframe 高度自适应
            layero.find('iframe').css('max-height', '500px');
        },
        restore: function (layero) {

            // 让 iframe 最高高度为 500px
            layero.find('iframe').css('max-height', '500px');
        },
        end: function () {
            //easyQuery("");
            //complexQuery("");
            //$('.tab-container .tab').click(switchTab);
        }
    });
}

function all(){
	// 当前激活的标签页
	if($("#all").is(':checked')){
		$("#tbody").find("tr").each(function(){
			var obj1 =$(this).find("td").eq(0).find("input");
			obj1.prop("checked",true)
			checkBoxData[tabCurrent].push(obj1.val());
			return true;
		})
	}else{
		$("#tbody").find("tr").each(function(){
			$(this).find("td").eq(0).find("input").prop("checked",false)
			checkBoxData[tabCurrent]=[];
		})
	}
	console.log(checkBoxData[tabCurrent])
}
/**
 * 加载标签页表格
 */
// function loadPanelTable() {

//     $('.boostrap-table').before($(''
//         + '<table id="t' + $('.tab-panel-container .tab-panel').not('.hide').index() + '"></table>'
//     ));
//     $('.boostrap-table').remove();

//     var data = [];
//     for (let i = 0; i < 989; ++i) {
//         data.push({
//             id: i,
//             name: String(Math.ceil(Math.random() * i)),
//             price: '$' + (Math.ceil(Math.random() * i))
//         });
//     }

//     var index = $('.tab-panel-container .tab-panel').not('.hide').index();
//     console.log('index', index);
//     $('#t' + (index + 1)).bootstrapTable({
//         striped: true, // 条纹样式
//         undefinedText: "", // 当数据为 undefined 时显示的字符
//         sortClass: undefined, // 被排序的td元素的类名
//         height: 500, // 表格高度，可用于固定表头
//         pagination: true, // 是否分页，默认为否
//         paginationLoop: false, // 分页无限循环，默认为是
//         onlyInfoPagination: false, // 设置为 true 只显示总数据数，而不显示分页按钮。需要设置 pagination='true'
//         sidePagination: 'client', // 设置在哪里进行分页，可选值为 'client' 或者 'server'。设置 'server'时，必须设置服务器数据地址（url）或者重写ajax方法
//         pageNumber: 1, // 如果设置了分页，首页页码
//         pageSize: 30, // 如果设置了分页，页面数据条数
//         pageList: [30, 50, 100, 'all'], // 如果设置了分页，设置可供选择的页面数据条数。设置为 All 或者 Unlimited，则显示所有记录
//         columns: [
//             {
//                 field: 'id',
//                 title: 'Item ID'
//             },
//             {
//                 field: 'name',
//                 title: 'Item Number'
//             },
//             {
//                 field: 'price',
//                 title: 'Item Price'
//             }],
//         data: data
//     });
// }

function complexQuery(pm) {
    complexQueryP = pm;
    initPanel();
}

/**
 * 组合查询
 */
function complexFind() {
    $('.tab-container .tab').unbind('click');
    layer.open({
        type: 2,
        title: '组合查询',
        content: '/modules/dagl/bmgl/complexFind.html?tName=' + tabCurrent,
        area: ['700px', '500px'],
        offset: 'lb',
        resize: false,
        maxmin: true,
        shade: 0,
        success: function (layero, index) {
            // layer.iframeAuto(index);
            indexx = index;
        },
        full: function (layero) {

            // 让 iframe 高度自适应
            // layero.find('iframe').css('max-height', '500px');
        },
        restore: function (layero) {

            // 让 iframe 最高高度为 500px
            layero.css({'height':'500px','width':'700px','top':'calc(100% - 500px)'});
        },
        end: function () {
            //easyQuery("");
            complexQuery("");
            //$('.tab-container .tab').click(switchTab);
        }
    });
}

/**
 * 提交操作
 * @returns
 */
function submitData(event) {

    // 阻止事件冒泡
    window.event ? window.event.cancelBubble = true : event.stopPropagation();

    var fids = checkBoxData[tabCurrent].toString();//获取选中行的id
    layer.confirm("确定要移交选中的数据吗？", { icon: 3 }, function (e) {
        layer.close(e);
        $.ajax({
            type: "POST",
            url: "/dagl/bmgl/recordSubmit",
            data: {fids: fids,tName: tabCurrent},
            dataType: "json",
            success: function (data) {
                if ('1' == data.flag) {
                    var msg = "";
                    var successList = data.data[0].successList;
                    if(successList.length>0){
                        msg +="<font style='color: green'>";
                        for(var i=0;i<successList.length;i++){
                            msg += successList[i].MAINTITLE+", ";
                        }
                        msg += "移交成功!</font><br/>";
                    }


                    var alreadySubmmitList = data.data[0].alreadySubmmitList;
                    if(alreadySubmmitList.length>0){
                        msg +="<font style='color: red'>";
                        for(var i=0;i<alreadySubmmitList.length;i++){
                            msg += alreadySubmmitList[i].MAINTITLE+", ";
                        }
                        msg += "已为移交待审核或者已移交，移交失败!</font><br/>";
                    }

                    var P_NotSubmmitList = data.data[0].P_NotSubmmitList;
                    if(P_NotSubmmitList.length>0){
                        msg +="<font style='color: red'>";
                        for(var i=0;i<P_NotSubmmitList.length;i++){
                            msg += P_NotSubmmitList[i].MAINTITLE+", ";
                        }
                        msg += "上级档案尚未移交（请先移交上级档案），移交失败！</font><br/>";
                    }

                    var NotAssociatedList = data.data[0].NotAssociatedList;
                    if(NotAssociatedList.length>0){
                        msg +="<font style='color: red'>";
                        for(var i=0;i<NotAssociatedList.length;i++){
                            msg += NotAssociatedList[i].MAINTITLE+", ";
                        }
                        msg += "尚未组卷，移交失败!</font><br/>";
                    }

                    layer.alert(msg,{title:'移交结果'});

                } else {
                    layer.msg("移交失败，请刷新页面再次操作", {
                        icon: 5
                    });
                }
            },
            error: function (data) {
            }
        });
    });
}
/*
 * 鼠标点击效果
 */
function dianjixiaoguo(){
	$('.tab-container .tab').click(switchTab);
}