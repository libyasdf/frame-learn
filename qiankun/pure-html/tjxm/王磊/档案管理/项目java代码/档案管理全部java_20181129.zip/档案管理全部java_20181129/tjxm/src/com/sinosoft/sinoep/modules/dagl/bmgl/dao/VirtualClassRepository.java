package com.sinosoft.sinoep.modules.dagl.bmgl.dao;

import java.util.List;

import com.sinosoft.sinoep.modules.dagl.bmgl.entity.VirtualClass;

public interface VirtualClassRepository {

	List<VirtualClass> findTree();
}
