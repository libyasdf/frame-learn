function formValidator(){
	//校验考试基本信息
	$('#form').bootstrapValidator({
        message: 'This value is not valid',
        group:".rowGroup",
        excluded:[":disabled"],
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
        	newMaintitle: {
            	//trigger:"change",
                validators: {
                    notEmpty: {
                        message: '新主管人不能为空！'
                    }
                }
            },
            changeDate: {
				//trigger:"change",//监听onchange事件
				validators: {
					notEmpty: {
						message: '更变日期不能为空！'
					}
				}
			},
			newBasefolderUnitName: {
				//trigger:"change",//监听onchange事件
				validators: {
					notEmpty: {
						message: '新主管单位不能为空！'
					}
				}
			},
			changeNo: {
				//trigger:"change",//监听onchange事件
				validators: {
					notEmpty: {
						message: '更变单号不能为空！'
					}
				}
			},
			registerDate: {
				//trigger:"change",//监听onchange事件
				validators: {
					notEmpty: {
						message: '登记日期不能为空！'
					}
				}
			},
			remark: {
				//trigger:"change",//监听onchange事件
				validators: {
					notEmpty: {
						message: '更变缘由不能为空！'
					}
				}
			},
	        submitHandler: function (validator, form, submitButton) {
	        	alert('submit');
	        }
        }
    });
	
}
