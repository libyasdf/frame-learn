package com.sinosoft.sinoep.modules.dagl.daly.borrow.dao;

import com.sinosoft.sinoep.common.jpa.repository.BaseRepository;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.entity.DaglBorrow;

public interface DaglBorrowDao  extends BaseRepository<DaglBorrow, String> {
}
