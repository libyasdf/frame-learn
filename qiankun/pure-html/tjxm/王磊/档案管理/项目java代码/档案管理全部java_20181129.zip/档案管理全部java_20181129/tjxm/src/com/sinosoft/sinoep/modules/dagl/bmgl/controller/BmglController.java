package com.sinosoft.sinoep.modules.dagl.bmgl.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.sinosoft.sinoep.common.util.PageImpl;
import com.sinosoft.sinoep.handlerInterceptor.LogAnnotation;
import com.sinosoft.sinoep.modules.dagl.bmgl.entity.VirtualClass;
import com.sinosoft.sinoep.modules.dagl.bmgl.services.BmglService;
import com.sinosoft.sinoep.modules.system.config.dictionary.entity.DataDictionary;
import com.sinosoft.sinoep.modules.system.config.dictionary.services.DataDictionaryService;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("dagl/bmgl")
public class BmglController {

	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private BmglService bmglService;
	
	@Autowired
	private DataDictionaryService service;

	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * String
	 * TODO 动态获取表单列
	 */
	@LogAnnotation(value = "query",opName = "动态获取表单列")
	@RequestMapping(value="findAdd",produces = "application/json;charset=utf-8")
	@ResponseBody
	public String findAdd(String tName){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("flag", 1);
		List<Map<String, Object>> dynamicFind = bmglService.dynamicFind(tName);
		String jsonStr = JSON.toJSONString(dynamicFind,SerializerFeature.WriteMapNullValue);
		jsonObject.put("data", dynamicFind);
		return jsonStr;
		
	} 
	
	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * String
	 * TODO 动态获取标签
	 */
	@LogAnnotation(value = "query",opName = "动态获取标签")
	@RequestMapping(value="findLabel",produces = "application/json;charset=utf-8")
	@ResponseBody
	public String findLabel(String tName){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("flag", 1);
		List<Map<String,Object>> findLabel = bmglService.findLabel(tName);
		String jsonStr = JSON.toJSONString(findLabel);
		jsonObject.put("data", jsonStr);
		return jsonStr;
		
	} 
	
	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * String
	 * TODO 动态获取标签DAK
	 */
	@LogAnnotation(value = "query",opName = "动态获取标签DAK")
	@RequestMapping(value="findLabelDAK",produces = "application/json;charset=utf-8")
	@ResponseBody
	public String findLabelDAK(String tName){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("flag", 1);
		List<Map<String,Object>> findLabel = bmglService.findLabelDAK(tName);
		String jsonStr = JSON.toJSONString(findLabel);
		jsonObject.put("data", jsonStr);
		return jsonStr;
		
	} 
	
	/**
	 * 
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * String
	 * TODO 动态加入表数据
	 */
	@LogAnnotation(value = "query",opName = "动态加入表数据")
	@RequestMapping(value="dynamicAdd",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject dynamicAdd(String jsonStr,String tName){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("flag", 0);
		int dynamicAdd = bmglService.dynamicAdd(jsonStr, tName);
		if (dynamicAdd>0) {
			jsonObject.put("flag", 1);
		}
		return jsonObject;
		
	} 
	
	/**
	 *
	 * @param jsonStr
	 * @param tName
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 动态修改
	 */
	@LogAnnotation(value = "query",opName = "动态修改")
	@RequestMapping(value="dynamicUpdate",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject dynamicUpdate(String jsonStr,String tName,String key,String value){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("flag", 0);
		int dynamicAdd = bmglService.dynamicUpdate(jsonStr, tName, key, value);
		if (dynamicAdd>0) {
			jsonObject.put("flag", 1);
		}
		return jsonObject;
		
	} 
	
	/**
	 * 
	 * @param jsonStr
	 * @param tName
	 * @param key
	 * @param value
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 动态列表
	 */
	@LogAnnotation(value = "query",opName = "动态列表")
	@RequestMapping(value="dynamicList",produces = "application/json;charset=utf-8")
	@ResponseBody
	public String dynamicList(String jsonStr,String tName,PageImpl pageImpl,String conditions,String fids,String parameters,String complexParam,String danweihao){
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("flag", 0);
		List<Map<String,Object>> dynamicList = bmglService.dynamicList(tName, pageImpl, jsonStr, conditions, fids,parameters,complexParam,danweihao);
		String jsonString = JSON.toJSONString(dynamicList,SerializerFeature.WriteMapNullValue);
		return jsonString;
		
	} 
	
	/**
	 * 
	 * @param jsonStr
	 * @param tName
	 * @param pageImpl
	 * @param conditions
	 * @param fids
	 * @return
	 * @author 颜振兴
	 * String
	 * TODO 门类树
	 */
	@LogAnnotation(value = "query",opName = "门类树")
	@RequestMapping(value="findTree",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject findTree(){
		JSONObject jsonObject = new JSONObject();
		JSONObject data = new JSONObject();
		jsonObject.put("flag", 0);
		List<VirtualClass> findTree = bmglService.findTree();
		if (findTree.size()>0) {
			jsonObject.put("flag", 1);
			data.put("total", findTree.size());
			data.put("rows", findTree);
			jsonObject.put("data", data);
		}
		return jsonObject;
		
	} 
	
	/**
	 * 
	 * @param tName
	 * @param fids
	 * @param column
	 * @param value1
	 * @param value2
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 替换
	 */
	@LogAnnotation(value = "query",opName = "替换")
	@RequestMapping(value="replace",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject replace(String tName, String fids, String column, String value1, String value2) {
		JSONObject json = new JSONObject();
		json.put("flag", 0);
		int replace = bmglService.replace(tName, fids, column, value1, value2);
		if (replace>0) {
			json.put("flag", 1);
			json.put("num", replace);
		}
		return json;
		
	}
	
	/**
	 * 
	 * @param tName
	 * @param id
	 * @return
	 * @author 颜振兴
	 * String
	 * TODO 根据id获取一条数据
	 */
    @LogAnnotation(value = "query",opName = "根据id获取一条数据")
	@RequestMapping(value="findById",produces = "application/json;charset=utf-8")
	@ResponseBody
	public String findById(String tName, String id) {
		List<Map<String, Object>> findById = bmglService.findById(tName, id);
		String jsonString = JSON.toJSONString(findById,SerializerFeature.WriteMapNullValue);
		return jsonString;
		
	}
	
	/**
	 *
	 * @param column
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 添加树的节点
	 */
	@LogAnnotation(value = "query",opName = "添加树的节点")
	@RequestMapping(value="addTree",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject addTree(VirtualClass column) {
		JSONObject json = new JSONObject();
		json.put("flag", 1);
		VirtualClass addTree = bmglService.addTree(column);
		json.put("data", addTree);
		return json;
		
	}
	
	/**
	 * 
	 * @param id
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 删除树的节点以及子节点
	 */
	@LogAnnotation(value = "query",opName = "删除树的节点以及子节点")
	@RequestMapping(value="deleteTree",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject deleteTree(String id) {
		JSONObject json = new JSONObject();
		json.put("flag", 1);
		bmglService.deleteTree(id);
		return json;
		
	}
	
	/**
	 * 
	 * @param tName
	 * @param id
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 动态删除一条数据
	 */
	@LogAnnotation(value = "query",opName = "动态删除一条数据")
	@RequestMapping(value="dynamicDelete",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject dynamicDelete(String tName,String id) {
		JSONObject json = new JSONObject();
		json.put("flag", 0);
		int dynamicDelete = bmglService.dynamicDelete(tName, id);
		if (dynamicDelete>0) {
			json.put("flag", 1);
		}
		return json;
		
	}
	
	
	/**
	 * 
	 * @param tName
	 * @param categoryCode
	 * @param all
	 * @param ranking
	 * @return
	 * @author 颜振兴
	 * JSONObject 查询档案规则
	 * TODO
	 */
	@LogAnnotation(value = "query",opName = "查询档案规则")
	@RequestMapping(value="findDHGZ",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject findDHGZ(String tName,String categoryCode,int all,int 
			ranking) {
		JSONObject json = new JSONObject();
		String id = bmglService.findMenById(categoryCode);
		List<Map<String, Object>> list = bmglService.findDHGZbyMCode(id);
		int size = list.size();
		int num = size-(all-ranking);
		List<Map<String, Object>> newList = new ArrayList<>();
		for(int i =0;i<num;i++) {
			newList.add(i, list.get(i));
		}
		String replaceAll = com.alibaba.fastjson.JSONObject.toJSONString(newList,SerializerFeature.WriteMapNullValue).replaceAll("null", "\"\"");
		Map<String, Object> findDAGLByTableName = bmglService.findDAGLByTableName(tName);
		String findZHbycolnum = bmglService.findZHbycolnum(tName, findDAGLByTableName.get("S_COL_NAME").toString().toLowerCase());
		findDAGLByTableName.put("ZH", findZHbycolnum);
		String replaceAll2 = com.alibaba.fastjson.JSONObject.toJSONString(findDAGLByTableName,SerializerFeature.WriteMapNullValue).replaceAll("null", "\"\"");
		
		json.put("flag", 1);
		JSONObject data = new JSONObject();
		if (all==ranking) {
			data.put("rows", replaceAll);
			data.put("colsf", replaceAll2);
			Map<String, String> map = new HashMap<>();
			map.put("archive_no", bmglService.findZHbycolnum(tName, "archive_no"));
			data.put("colsz", map);
			json.put("data", data);
		}else if(ranking>1&&ranking<all) {
			Map<String, Object> TableName = bmglService.findDAGLByTableNameF(tName);
			String findZHbycolnum1 = bmglService.findZHbycolnum(tName, (String)TableName.get("S_COL_NAME"));
			findDAGLByTableName.put("ZH", findZHbycolnum1);
			String replaceAll3 = com.alibaba.fastjson.JSONObject.toJSONString(TableName,SerializerFeature.WriteMapNullValue).replaceAll("null", "\"\"");
			data.put("rows", replaceAll);
			data.put("colsf", replaceAll2);
			data.put("colsz", replaceAll3);
			json.put("data", data);
		}else if(ranking==1){
			data.put("rows", replaceAll);
			data.put("colsf", replaceAll2);
			json.put("data", data);
		}
		
		return json;
		
	}
	
	/**
	 * 
	 * @param categoryCode
	 * @return
	 * @author 颜振兴
	 * List<Map<String, Object>>
	 * TODO 根据门类号获取档号规则 替换的时候用
	 */
	@LogAnnotation(value = "query",opName = "根据门类号获取档号规则 替换的时候用")
	@RequestMapping(value="findDHGZ2",produces = "application/json;charset=utf-8")
	@ResponseBody
	public List<Map<String, Object>> findDHGZ2(String categoryCode) {
		String id = bmglService.findMenById(categoryCode);
		List<Map<String, Object>> list = bmglService.findDHGZbyMCode(id);
		if (list!=null&&!list.isEmpty()) {
			return list;
		}else {
			return null;
		}
	}
	
	/**
	 *
	 * @param marks
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 查询指定的数据字典
	 */
	@LogAnnotation(value = "query",opName = "查询指定的数据字典")
	@RequestMapping(value="byDataDictionary",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject byDataDictionary(String marks) {
		JSONObject json = new JSONObject();
		String[] markss = marks.split(",");
		for(String mark : markss) {
			List<DataDictionary> dicts;
			try {
			dicts = service.getListByMark(mark,"1");
				Map<String, String> map = new HashMap<>();
				for (DataDictionary dic : dicts) {
					map.put(dic.getCode(), dic.getName());
				}
				json.put(mark, map);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return json;
	}

	/**
	 * TODO 获取当前标签页勾选的数据（多行）
	 * @author 李颖洁  
	 * @date 2018年11月22日上午11:17:45
	 * @param tName
	 * @param fids
	 * @return JSONObject
	 */
	@LogAnnotation(value = "query",opName = "查询勾选的多行数据")
	@RequestMapping(value="getSelectedData",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject getSelectedData(String tName, String fids) {
		JSONObject json = new JSONObject();
		JSONObject data = new JSONObject();
		json.put("flag", "0");
		try {
			List<Map<String,Object>> list = bmglService.getSelectedData(tName, fids);
			json.put("flag", "1");
			data.put("rows", JSON.toJSONString(list));
			json.put("data", data);
		} catch (Exception e) {
			//log.error(e.getMessage(),e);
			json.put("msg", "获取失败！");
		}
		return json;
	}

	/**
	 * TODO 获取未组卷的文件
	 * @author 李颖洁
	 * @date 2018年11月22日上午11:17:45
	 * @param tName
	 * @param fids
	 * @return JSONObject
	 */
	@LogAnnotation(value = "query",opName = "查询未组卷的文件")
	@RequestMapping(value="getNotSetVolumeList",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject getNotSetVolumeList(String tName,String basefolderUnit) {
		JSONObject json = new JSONObject();
		JSONObject data = new JSONObject();
		json.put("flag", "0");
		try {
			List<Map<String,Object>> list = bmglService.getNotSetVolumeList(tName,basefolderUnit);
			json.put("flag", "1");
			data.put("rows", JSON.toJSONString(list));
			json.put("data", data);
		} catch (Exception e) {
			//log.error(e.getMessage(),e);
			json.put("msg", "获取失败！");
		}
		return json;
	}

	/**
	 * TODO 获取案卷下的卷内信息
	 * @author 李颖洁
	 * @date 2018年11月22日上午11:17:45
	 * @param tName  父表表名
	 * @param fid 父表选中的id
	 * @return JSONObject
	 */
	@LogAnnotation(value = "query",opName = "查询父表对应的字表数据")
	@RequestMapping(value="getChildData",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject getChildDataByFartherId(String tName, String fid,String basefolderUnit) {
		JSONObject json = new JSONObject();
		JSONObject data = new JSONObject();
		json.put("flag", "0");
		try {
			List<Map<String,Object>> list = bmglService.getChildDataByFartherId(tName, fid,basefolderUnit);
			json.put("flag", "1");
			data.put("rows", JSON.toJSONString(list));
			json.put("data", data);
		} catch (Exception e) {
			//log.error(e.getMessage(),e);
			json.put("msg", "获取失败！");
		}
		return json;
	}

	/**
	 * TODO 获取卷内的关联字段
	 * @author 李颖洁
	 * @date 2018年11月22日上午11:17:45
	 * @param tName  父表表名
	 * @return JSONObject
	 */
	@LogAnnotation(value = "query",opName = "获取卷内的关联字段")
	@RequestMapping(value="getFileConnationCol",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject getFileConnationCol(String tName) {
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			Map<String,Object> map = bmglService.findDAGLByTableNameF(tName);
			json.put("flag", "1");
			json.put("data", JSON.toJSONString(map));
		} catch (Exception e) {
			//log.error(e.getMessage(),e);
			json.put("msg", "获取失败！");
		}
		return json;
	}

	/**
	 * TODO 拆卷/组卷（卷内文件从案卷中调出/调入）
	 * @author 李颖洁
	 * @date 2018年11月23日下午4:07:40
	 * @param tName 卷内表名
	 * @param ids 选中的卷内id
	 * @param archiveFlag  组卷标识
	 * @param conCol 关联字段
	 * @param conCol 关联字段的值
	 * @return JSONObject
	 */
	@LogAnnotation(value = "query",opName = "卷内文件从案卷中调出/调入")
	@RequestMapping(value="openOrSetVolume",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject openOrSetVolume(String tName,String ids,String archiveFlag,String conCol,String conVal) {
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			int num = bmglService.openVolume(tName,ids,archiveFlag,conCol,conVal);
			json.put("flag", "1");
			json.put("data", num);
		} catch (Exception e) {
			//log.error(e.getMessage(),e);
			json.put("msg", "获取失败！");
		}
		return json;
	}

	/**
	 * TODO 档案卷内文件确认调整
	 * @author 李颖洁
	 * @date 2018年11月24日下午6:05:24
	 * @param tName 卷内表名
	 * @param conCol 关联字段
	 * @param conVal 关联字段值
	 * @param data 更改的数据项
	 * @return JSONObject
	 */
	@LogAnnotation(value = "update",opName = "档案卷内文件确认调整")
	@RequestMapping(value="confirmAdjust",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject confirmAdjust(String tName,String conCol,String conVal,String data,String categoryCode) {
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			int num = bmglService.updateFileRelation(tName,conCol,conVal,data,categoryCode);
			if(num==1){
				json.put("flag", "1");
				json.put("data", num);
			}else{
				json.put("msg", "调整失败！");
			}
		} catch (Exception e) {
			//log.error(e.getMessage(),e);
			json.put("msg", "调整失败！");
		}
		return json;
	}

	/**
	 * @Author 王富康
	 * @Description //TODO 档案提交
	 * @Date 2018/11/22 19:34
	 * @Param [tName, fids]
	 * @return net.sf.json.JSONObject
	 **/
	@LogAnnotation(value = "query",opName = "档案提交")
	@RequestMapping(value="recordSubmit",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject recordSubmit(String tName, String fids) {
		JSONObject json = new JSONObject();
		json.put("flag", "0");
		try {
			List<Map<String,Object>> list = bmglService.recordSubmit(tName, fids);
			String replaceAll = com.alibaba.fastjson.JSONObject.toJSONString(list,SerializerFeature.WriteMapNullValue).replaceAll("null", "\"\"");
			json.put("flag", "1");
			json.put("data", replaceAll);
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			json.put("msg", "获取失败！");
		}
		return json;

	}
	
	/**
	 * 
	 * @param column
	 * @param relevancyId
	 * @param tName
	 * @param chushiId
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 判断关联字段是否存在 返回1可用不存在 返回0 数据库存在
	 */
	@LogAnnotation(value = "query",opName = "判断关联字段的是否纯在")
	@RequestMapping(value="isRepetition",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject isRepetition(String column, String relevancyId,String tName,String chushiId) {
		JSONObject json = new JSONObject();
		
		int repetition = bmglService.isRepetition(column, relevancyId, tName, chushiId);
		if(repetition>0) {
			json.put("flag", "0");
		}else {
			json.put("flag", "1");
		}
		return json;

	}

	/**
	 * 
	 * @param tName
	 * @param fids
	 * @return
	 * @author 颜振兴
	 * String
	 * TODO 根据id查数据
	 */
	@LogAnnotation(value = "query",opName = "根据id查数据")
	@RequestMapping(value="findParentData",produces = "application/json;charset=utf-8")
	@ResponseBody
	public String findParentData(String tName,String fids) {
		Map<String, Object> findParentData = bmglService.findParentData(tName, fids);
		String jsonString = JSON.toJSONString(findParentData,SerializerFeature.WriteMapNullValue);
		return jsonString;
	}
	
	/**
	 * 
	 * @param tName
	 * @param fids
	 * @return
	 * @author 颜振兴
	 * String
	 * TODO 批量删除
	 */
	@LogAnnotation(value = "delete",opName = "批量删除")
	@RequestMapping(value="dynamicDeletes",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject dynamicDeletes(String tName,String ids) {
		JSONObject json = new JSONObject();
		int i = bmglService.dynamicDeletes(tName,ids);
		if(i>0) {
			json.put("flag", 1);
			json.put("total", i);
		}else {
			json.put("flag", 0);
		}
		return json;
	}
	
	/**
	 * 
	 * @param tName
	 * @param chushiid
	 * @return
	 * @author 颜振兴
	 * JSONObject
	 * TODO 查询数量
	 */
	@LogAnnotation(value = "query",opName = "查询数量")
	@RequestMapping(value="findThisTotal",produces = "application/json;charset=utf-8")
	@ResponseBody
	public JSONObject findThisTotal(String tName, String chushiid) {
		JSONObject json = new JSONObject();
		int i = bmglService.findThisTotal(tName, chushiid);
		json.put("data", i);
		return json;
	}
}
