package com.sinosoft.sinoep.modules.dagl.daly.borrow.services;


import com.sinosoft.sinoep.common.constant.CommonConstants;
import com.sinosoft.sinoep.common.constant.ConfigConsts;
import com.sinosoft.sinoep.common.util.CommonUtils;
import com.sinosoft.sinoep.common.util.HttpRequestUtil;
import com.sinosoft.sinoep.common.util.PageImpl;
import com.sinosoft.sinoep.common.util.SpringBeanUtils;
import com.sinosoft.sinoep.message.model.NotityMessage;
import com.sinosoft.sinoep.message.service.NotityService;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.dao.DaglBorrowDao;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.dao.DaglFileDao;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.entity.DaglBorrow;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.entity.DaglFile;
import com.sinosoft.sinoep.modules.taskplan.entity.TaskPlan;
import com.sinosoft.sinoep.user.util.UserUtil;
import com.sinosoft.sinoep.waitNoflow.entity.SysWaitNoflow;
import com.sinosoft.sinoep.waitNoflow.services.SysWaitNoflowService;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Auther:邴秀慧
 * @Description:档案借阅服务类
 * @Date:2018/11/10 9:49
 */
@Service
public class DaglBorrowServiceImpl implements DaglBorrowService {

    @Autowired
    private DaglBorrowDao daglBorrowDao;

    @Autowired
    private DaglFileDao daglFileDao;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private SysWaitNoflowService sysWatiNoflowService;

    /**
     * @Auther:邴秀慧
     * @Description:查询草稿列表
     * @Date:2018/11/10 9:42
     */
    @Override
    public PageImpl getPageListDraft(Pageable pageable, PageImpl pageImpl, DaglBorrow daglBorrow) throws Exception {
        pageImpl.setFlag("0");
        StringBuilder querySql = new StringBuilder();
        List<Object> para = new ArrayList<>();

        querySql.append("	from DaglBorrow t ");
        querySql.append("	where t.visible = '" + CommonConstants.VISIBLE[1] + "' and t.subflag = '0' ");

        //拼接条件
        querySql.append("	and t.creUserId = ?");
        para.add(UserUtil.getCruUserId());
        if (StringUtils.isNotBlank(daglBorrow.getYear())) {
            String startYear = daglBorrow.getYear().substring(0, (daglBorrow.getYear().length() + 1) / 2 - 1).trim();
            String endYear = daglBorrow.getYear().substring((daglBorrow.getYear().length() + 1) / 2, daglBorrow.getYear().length()).trim();
            querySql.append("   and t.year >= ?");
            querySql.append("   and t.year <= ?");
            para.add(startYear);
            para.add(endYear);
        }
        if (StringUtils.isNotBlank(daglBorrow.getCreTime())) {
            String startTime = daglBorrow.getCreTime().substring(0, (daglBorrow.getCreTime().length() + 1) / 2 - 1).trim();
            String endTime = daglBorrow.getCreTime().substring((daglBorrow.getCreTime().length() + 1) / 2, daglBorrow.getCreTime().length()).trim();
            querySql.append("   and substr(t.creTime,0,10) >= ?");
            querySql.append("   and substr(t.creTime,0,10) <= ?");
            para.add(startTime);
            para.add(endTime);
        }
        if (StringUtils.isNotBlank(daglBorrow.getUsePurpose())) {
            querySql.append("   and t.usePurpose = ?");
            para.add(daglBorrow.getUsePurpose());
        }
        //拼接排序语句
        if (StringUtils.isBlank(pageImpl.getSortName())) {
            querySql.append("  order by t.creTime desc");
        } else {
            querySql.append("  order by t." + pageImpl.getSortName() + " " + pageImpl.getSortOrder() + "");
        }

        Page<DaglBorrow> page = daglBorrowDao.query(querySql.toString(), pageable, para.toArray());
        //草稿列表，添加操作列
        List<DaglBorrow> content = page.getContent();
        for (DaglBorrow daglBorrowTemp : content) {
            if (ConfigConsts.START_FLAG.equals(daglBorrowTemp.getSubflag())) {
                daglBorrowTemp.setCz(CommonConstants.OPTION_UPDATE + "," + CommonConstants.OPTION_DELETE);
            }
        }
        pageImpl.setFlag("1");
        pageImpl.getData().setRows(content);
        pageImpl.getData().setTotal((int) page.getTotalElements());
        return pageImpl;
    }

    /**
     * @Auther:邴秀慧
     * @Description:保存主子表
     * @Date:2018/11/10 9:42
     */
    @Override
    public DaglBorrow saveForm(DaglBorrow daglBorrow) throws Exception {
        String nodeFlag = daglBorrow.getNodeFlag();
        List<DaglFile> newFileList = daglBorrow.getFileList();
        daglBorrow.setVisible(CommonConstants.VISIBLE[1]);
        String creTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String year = new SimpleDateFormat("yyyy").format(new Date());
        if (StringUtils.isBlank(daglBorrow.getId())) {
            daglBorrow.setCreTime(creTime);
            daglBorrow.setCreUserId(UserUtil.getCruUserId());
            daglBorrow.setCreUserName(UserUtil.getCruUserName());
            daglBorrow.setCreChushiName(UserUtil.getCruChushiName());
            daglBorrow.setCreChushiId(UserUtil.getCruChushiId());
            daglBorrow.setCreJuName(UserUtil.getCruJuName());
            daglBorrow.setCreJuId(UserUtil.getCruJuId());
            daglBorrow.setCreDeptId(UserUtil.getCruDeptId());
            daglBorrow.setCreDeptName(UserUtil.getCruDeptName());
            daglBorrow.setUpdateTime(creTime);
            daglBorrow.setUpdateUserId(UserUtil.getCruUserId());
            daglBorrow.setUpdateUserName(UserUtil.getCruUserName());
            if (StringUtils.isNotBlank(daglBorrow.getFlowType()) && daglBorrow.getFlowType().equals("0")) {
                daglBorrow.setTitle(creTime + daglBorrow.getUnitName() + daglBorrow.getBorrowUserName() + "借阅本单位档案申请");
                daglBorrow.setFileUnitId(UserUtil.getCruChushiId());
                daglBorrow.setFileUnitName(UserUtil.getCruChushiName());
            } else {
                daglBorrow.setTitle(creTime + daglBorrow.getUnitName() + daglBorrow.getBorrowUserName() + "借阅非本单位档案申请");
            }

            daglBorrow.setSubflag("0");
            daglBorrow.setYear(year);
            daglBorrow = daglBorrowDao.save(daglBorrow);
        } else {
            DaglBorrow oldDaglBorrow = daglBorrowDao.findOne(daglBorrow.getId());
            oldDaglBorrow.setTitle(daglBorrow.getTitle());
            oldDaglBorrow.setUpdateTime(creTime);
            oldDaglBorrow.setUpdateUserId(UserUtil.getCruUserId());
            oldDaglBorrow.setUpdateUserName(UserUtil.getCruUserName());
            oldDaglBorrow.setBorrowUserId(daglBorrow.getBorrowUserId());
            oldDaglBorrow.setBorrowUserName(daglBorrow.getBorrowUserName());
            oldDaglBorrow.setUnitName(daglBorrow.getUnitName());
            oldDaglBorrow.setUnitId(daglBorrow.getUnitId());
            oldDaglBorrow.setUsePurpose(daglBorrow.getUsePurpose());
            oldDaglBorrow.setEmail(daglBorrow.getEmail());
            oldDaglBorrow.setPhone(daglBorrow.getPhone());
            oldDaglBorrow.setRemark(daglBorrow.getRemark());
            oldDaglBorrow.setBorrowDeptId(daglBorrow.getBorrowDeptId());
            oldDaglBorrow.setBorrowDeptName(daglBorrow.getBorrowDeptName());
            oldDaglBorrow.setFlowType(daglBorrow.getFlowType());
            if (StringUtils.isNotBlank(daglBorrow.getFlowType()) && daglBorrow.getFlowType().equals("0")) {
                oldDaglBorrow.setTitle(creTime + daglBorrow.getUnitName() + daglBorrow.getBorrowUserName() + "借阅本单位档案申请");
                if (StringUtils.isNotBlank(daglBorrow.getSubflag()) && daglBorrow.getSubflag().equals("0")) {
                    oldDaglBorrow.setFileUnitId(UserUtil.getCruChushiId());
                    oldDaglBorrow.setFileUnitName(UserUtil.getCruChushiName());
                }
            } else {
                oldDaglBorrow.setTitle(creTime + daglBorrow.getUnitName() + daglBorrow.getBorrowUserName() + "借阅非本单位档案申请");
                oldDaglBorrow.setFileUnitId(daglBorrow.getFileUnitId());
                oldDaglBorrow.setFileUnitName(daglBorrow.getFileUnitName());
            }
            daglBorrow = daglBorrowDao.save(oldDaglBorrow);
        }
        if (newFileList.size() > 0) {
            List<DaglFile> fileList = new ArrayList<DaglFile>();
            for (DaglFile daglFile : newFileList) {
                if (StringUtils.isBlank(daglFile.getId())) {
                    daglFile.setVisible(CommonConstants.VISIBLE[1]);
                    daglFile.setCreTime(creTime);
                    daglFile.setCreUserId(UserUtil.getCruUserId());
                    daglFile.setCreUserName(UserUtil.getCruUserName());
                    daglFile.setCreChushiName(UserUtil.getCruChushiName());
                    daglFile.setCreChushiId(UserUtil.getCruChushiId());
                    daglFile.setCreJuName(UserUtil.getCruJuName());
                    daglFile.setCreJuId(UserUtil.getCruJuId());
                    daglFile.setCreDeptId(UserUtil.getCruDeptId());
                    daglFile.setCreDeptName(UserUtil.getCruDeptName());
                    daglFile.setUpdateTime(creTime);
                    daglFile.setUpdateUserId(UserUtil.getCruUserId());
                    daglFile.setUpdateUserName(UserUtil.getCruUserName());
                    daglFile.setBelongUnitName(daglBorrow.getFileUnitName());
                    daglFile.setBelongUnitId(daglBorrow.getFileUnitId());
                    daglFile.setBorrowUserId(daglBorrow.getBorrowUserId());
                    daglFile.setBorrowUserName(daglBorrow.getBorrowUserName());
                    daglFile.setUnitId(daglBorrow.getUnitId());
                    daglFile.setUnitName(daglBorrow.getUnitName());
                    daglFile.setBorrowDeptId(daglBorrow.getBorrowDeptId());
                    daglFile.setBorrowDeptName(daglBorrow.getBorrowDeptName());
                   /* if (StringUtils.isNotBlank(daglFile.getIsBorrow()) && daglFile.getIsBorrow().equals("是")) {
                        daglFile.setStatus("1");
                    } else if (StringUtils.isNotBlank(daglFile.getIsBorrow()) && daglFile.getIsBorrow().equals("否")) {
                        daglFile.setStatus("0");
                    }*/
                    if (StringUtils.isNotBlank(daglBorrow.getIsRenew()) && daglBorrow.getIsRenew().equals("1")) {
                        daglFile.setBorrowId(daglFile.getBorrowId() + "," + daglBorrow.getId());
                    } else {
                        daglFile.setBorrowId(daglBorrow.getId());
                    }

                    daglFile = daglFileDao.save(daglFile);

                } else {
                    DaglFile oldDaglFile = daglFileDao.findOne(daglFile.getId());
                    oldDaglFile.setUpdateTime(creTime);
                    oldDaglFile.setUpdateUserId(UserUtil.getCruUserId());
                    oldDaglFile.setUpdateUserName(UserUtil.getCruUserName());
                    oldDaglFile.setFileCategory(daglFile.getFileCategory());
                    oldDaglFile.setFileNo(daglFile.getFileNo());
                    oldDaglFile.setFileName(daglFile.getFileName());
                    oldDaglFile.setFileNum(daglFile.getFileNum());
                    oldDaglFile.setClassification(daglFile.getClassification());
                    oldDaglFile.setUseWay(daglFile.getUseWay());
                    oldDaglFile.setBelongUnitId(daglFile.getBelongUnitId());
                    oldDaglFile.setBelongUnitName(daglFile.getBelongUnitName());
                    //oldDaglFile.setBorrowId(daglBorrow.getId());
                    oldDaglFile.setIsBorrow(daglFile.getIsBorrow());
                    oldDaglFile.setBelongUnitName(daglBorrow.getFileUnitName());
                    oldDaglFile.setBelongUnitId(daglBorrow.getFileUnitId());
                    oldDaglFile.setBorrowUserId(daglBorrow.getBorrowUserId());
                    oldDaglFile.setBorrowUserName(daglBorrow.getBorrowUserName());
                    oldDaglFile.setUnitId(daglBorrow.getUnitId());
                    oldDaglFile.setUnitName(daglBorrow.getUnitName());
                    oldDaglFile.setBorrowDeptId(daglBorrow.getBorrowDeptId());
                    oldDaglFile.setBorrowDeptName(daglBorrow.getBorrowDeptName());
                    if (StringUtils.isNotBlank(daglFile.getInRenew())) {
                        oldDaglFile.setInRenew(daglFile.getInRenew());
                    }
                    if (StringUtils.isNotBlank(nodeFlag) && nodeFlag.equals("1")) {//判断如果是：局档案部门审批节点保存经办人；
                        oldDaglFile.setHandleUserId(UserUtil.getCruUserId());
                        oldDaglFile.setHandleUserName(UserUtil.getCruUserName());
                    } else if (StringUtils.isNotBlank(nodeFlag) && nodeFlag.equals("2")) {//如果是归档单位领导保存批准人

                        oldDaglFile.setApproveUserId(UserUtil.getCruUserId());
                        oldDaglFile.setApproveUserName(UserUtil.getCruUserName());
                    }
                    if (StringUtils.isNotBlank(daglBorrow.getIsRenew()) && daglBorrow.getIsRenew().equals("1")) {
                        if (oldDaglFile.getBorrowId().indexOf(daglBorrow.getId()) < 0) {//没有存过就存储，防止同一个流程流程中一直保存
                            oldDaglFile.setBorrowId(oldDaglFile.getBorrowId() + "," + daglBorrow.getId());
                        }
                    } else {
                        oldDaglFile.setOrderNum(daglFile.getOrderNum());//不是续借的字表保存，排序字段
                        oldDaglFile.setBorrowId(daglBorrow.getId());
                    }
                    daglFile = daglFileDao.save(oldDaglFile);
                }
                fileList.add(daglFile);
            }
            daglBorrow.setFileList(fileList);
        }
        return daglBorrow;
    }

    /**
     * @Auther:邴秀慧
     * @Description:删除主表数据
     * @Date:2018/11/10 10:06
     */
    @Override
    public int deleteDaglBorrow(String id) throws Exception {
        String jpql = "update DaglBorrow t set t.visible = ? where t.id = ?";
        int num = daglBorrowDao.update(jpql, CommonConstants.VISIBLE[0], id);
        DaglBorrow daglBorrow = daglBorrowDao.findOne(id);
        List<DaglFile> fileList = daglFileDao.findByborrowIdContainingAndVisibleOrderByOrderNumAsc(daglBorrow.getId(), "1");
        if (fileList.size() > 0) {
            for (DaglFile daglFile : fileList) {
                if (StringUtils.isBlank(daglBorrow.getIsRenew()) || (StringUtils.isNotBlank(daglBorrow.getIsRenew()) && daglBorrow.getIsRenew().equals("0"))) {//不是续借的数据
                    String fileSql = "update DaglFile t set t.visible = ? where t.id = ?";
                    daglFileDao.update(fileSql, CommonConstants.VISIBLE[0], daglFile.getId());
                } else {
                    if (daglFile.getBorrowId().length() > 0 && daglFile.getBorrowId().indexOf(",") > 0) {
                        daglFile.setBorrowId(StringUtils.substringBeforeLast(daglFile.getBorrowId(), ","));
                        daglFile.setInRenew("0");
                        daglFileDao.save(daglFile);
                    }
                }
            }
        }
        return num;
    }

    /**
     * @Auther:邴秀慧
     * @Description:删除字表数据
     * @Date:2018/11/10 10:56
     */
    @Override
    public int deleteDaglFile(String ids) throws Exception {
        int num = 0;
        String[] idArr = ids.split(",");
        for (int i = 0; i < idArr.length; i++) {
            DaglFile daglFile = daglFileDao.findOne(idArr[i]);
            if (StringUtils.isBlank(daglFile.getInRenew()) || (StringUtils.isNotBlank(daglFile.getInRenew()) && daglFile.getInRenew().equals("0"))) {//不是续借的数据
                String fileSql = "update DaglFile t set t.visible = ? where t.id = ?";
                daglFileDao.update(fileSql, CommonConstants.VISIBLE[0], daglFile.getId());
                num++;
            } else {
                if (daglFile.getBorrowId().length() > 0 && daglFile.getBorrowId().indexOf(",") > 0) {
                    daglFile.setBorrowId(StringUtils.substringBeforeLast(daglFile.getBorrowId(), ","));
                    daglFile.setInRenew("0");
                    daglFileDao.save(daglFile);
                    num++;
                }
            }
        }
        return num;
    }

    /**
     * @Auther:邴秀慧
     * @Description:获取主子表的数据
     * @Date:2018/11/10 10:58
     */
    @Override
    public DaglBorrow getById(String id) throws Exception {
        List<DaglFile> daglFileList = new ArrayList<DaglFile>();
        DaglBorrow daglBorrow = daglBorrowDao.findOne(id);
        daglFileList = daglFileDao.findByborrowIdContainingAndVisibleOrderByOrderNumAsc("%" + daglBorrow.getId() + "%", "1");
        daglBorrow.setFileList(daglFileList);
        return daglBorrow;
    }

    /**
     * @Auther:邴秀慧
     * @Description:更新subflag的状态值
     * @Date:2018/11/13 20:09
     */
    @Override
    public DaglBorrow updateSubFlag(String id, String subflag) throws Exception {
        DaglBorrow daglBorrow = getById(id);
        daglBorrow.setSubflag(subflag);
        List<DaglFile> daglFileList = new ArrayList<DaglFile>();
        if (StringUtils.isNotBlank(daglBorrow.getSubflag()) && (daglBorrow.getSubflag().equals("4") || daglBorrow.getSubflag().equals("5"))) {
            daglFileList = daglFileDao.findByborrowIdContainingAndVisibleOrderByOrderNumAsc("%" + daglBorrow.getId() + "%", "1");
            for (DaglFile daglFile : daglFileList) {
                daglFile.setInRenew("0");
                daglFile.setFileStatus("1");
                daglFile.setShouldReturnDateFlag("1");
                daglFileDao.save(daglFile);
            }
        }
        return daglBorrowDao.save(daglBorrow);
    }

    @Override
    public PageImpl getAllFileList(Pageable pageable, PageImpl pageImpl, DaglFile daglFile) throws Exception {
        String creDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        pageImpl.setFlag("0");
        StringBuilder querySql = new StringBuilder();
        List<Object> para = new ArrayList<>();

        querySql.append("	from DaglFile t ");
        querySql.append("	where t.visible = '" + CommonConstants.VISIBLE[1] + "'");
        querySql.append("	and t.fileStatus = '" + CommonConstants.VISIBLE[1] + "'");
        // querySql.append("	and t.isBorrow = '是'");
        if (StringUtils.isNotBlank(daglFile.getFileNo())) {
            querySql.append("   and t.fileNo like ?");
            para.add("%" + daglFile.getFileNo() + "%");
        }
        if (StringUtils.isNotBlank(daglFile.getFileName())) {
            querySql.append("   and t.fileName like ?");
            para.add("%" + daglFile.getFileName() + "%");
        }
        if (StringUtils.isNotBlank(daglFile.getUseWay())) {
            querySql.append("   and t.useWay = ?");
            para.add(daglFile.getUseWay());
        }


        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("1")) {//待借阅
            querySql.append("   and t.isBorrow = '是' and t.shouldReturnDate is null");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("2")) {//待归还
            querySql.append("   and t.returnDate is null and shouldReturnDate>= '" + creDate + "'");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("3")) {//按时还
            querySql.append("   and to_date(t.returnDate,'yyyy-MM-dd') <= to_date(shouldReturnDate,'yyyy-MM-dd')");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("4")) {//逾期还
            querySql.append("   and to_date(t.returnDate,'yyyy-MM-dd') > to_date(shouldReturnDate,'yyyy-MM-dd')");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("5")) {//逾期未还
            querySql.append("   and t.returnDate is null and shouldReturnDate< '" + creDate + "'");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("6")) {//未借出
            querySql.append("   and t.isBorrow = '否' and t.shouldReturnDate is null");
        }
        //拼接排序语句
        if (StringUtils.isBlank(pageImpl.getSortName())) {
            querySql.append("  order by t.shouldReturnDateFlag desc, t.creTime desc");
        } else {
            querySql.append("  order by t." + pageImpl.getSortName() + " " + pageImpl.getSortOrder() + "");
        }

        Page<DaglFile> page = daglBorrowDao.query(querySql.toString(), pageable, para.toArray());
        //草稿列表，添加操作列
        List<DaglFile> content = page.getContent();
        for (DaglFile daglFileTemp : content) {
            //应还日期按钮
            if (StringUtils.isNotBlank(daglFileTemp.getIsBorrow()) && daglFileTemp.getIsBorrow().equals("是")
                    && StringUtils.isBlank(daglFileTemp.getReturnDate())
                    && StringUtils.isNotBlank(daglFileTemp.getShouldReturnDateFlag())
                    && daglFileTemp.getShouldReturnDateFlag().equals("1")) {
                String cz = "";
                if (StringUtils.isNotBlank(daglFileTemp.getCz())) {
                    cz = daglFileTemp.getCz() + "," + CommonConstants.OPTION_UPDATE;
                } else {
                    cz = CommonConstants.OPTION_UPDATE;
                }
                daglFileTemp.setCz(cz);

            }
            //归还按钮
            if (StringUtils.isNotBlank(daglFileTemp.getShouldReturnDate()) && StringUtils.isBlank(daglFileTemp.getReturnDate())) {
                String cz = "";
                if (StringUtils.isNotBlank(daglFileTemp.getCz())) {
                    cz = daglFileTemp.getCz() + ",revert";
                } else {
                    cz = "revert";
                }
                daglFileTemp.setCz(cz);
            }
            //手动催还
            if (StringUtils.isNotBlank(daglFileTemp.getShouldReturnDate()) &&
                    creDate.compareTo(daglFileTemp.getShouldReturnDate()) > 0 &&
                    StringUtils.isBlank(daglFileTemp.getReturnDate())) {
                String cz = "";
                if (StringUtils.isNotBlank(daglFileTemp.getCz())) {
                    cz = daglFileTemp.getCz() + ",urge";
                } else {
                    cz = "urge";
                }
                daglFileTemp.setCz(cz);
            }
        }
        pageImpl.setFlag("1");
        pageImpl.getData().setRows(content);
        pageImpl.getData().setTotal((int) page.getTotalElements());
        return pageImpl;
    }

    @Override
    public DaglFile fileEdit(String id) throws Exception {
        DaglFile daglFile = daglFileDao.findOne(id);
        return daglFile;
    }

    /**
     * @Auther:邴秀慧
     * @Description:保存应还日期
     * @Date:2018/11/15 11:19
     */
    @Override
    public DaglFile saveReturnDate(DaglFile daglFile) throws Exception {
        String creTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        DaglFile oldDaglFile = daglFileDao.findOne(daglFile.getId());
        oldDaglFile.setUpdateTime(creTime);
        oldDaglFile.setUpdateUserId(UserUtil.getCruUserId());
        oldDaglFile.setUpdateUserName(UserUtil.getCruUserName());
        oldDaglFile.setBorrowDate(daglFile.getBorrowDate());
        oldDaglFile.setShouldReturnDate(daglFile.getShouldReturnDate());
        oldDaglFile.setShouldReturnDateFlag("0");
        // oldDaglFile.setStatus("2");
        daglFile = daglFileDao.save(oldDaglFile);
        return daglFile;
    }

    @Override
    public PageImpl getInBorrowList(Pageable pageable, PageImpl pageImpl, DaglFile daglFile) throws Exception {
        String creDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        pageImpl.setFlag("0");
        StringBuilder querySql = new StringBuilder();
        List<Object> para = new ArrayList<>();

        querySql.append("	from DaglFile t ");
        querySql.append("	where t.visible = '" + CommonConstants.VISIBLE[1] + "'");
        //querySql.append("	and t.isBorrow = '是'");
        //querySql.append("	and t.status in ('2','5')");
        querySql.append("	and t.fileStatus = '" + CommonConstants.VISIBLE[1] + "'");
        querySql.append("	and t.borrowUserId = '" + UserUtil.getCruUserId() + "'");
        querySql.append("	and t.shouldReturnDate is not null");
        querySql.append("	and t.returnDate is  null");
        if (StringUtils.isNotBlank(daglFile.getFileNo())) {
            querySql.append("   and t.fileNo like ?");
            para.add("%" + daglFile.getFileNo() + "%");
        }
        if (StringUtils.isNotBlank(daglFile.getFileName())) {
            querySql.append("   and t.fileName like ?");
            para.add("%" + daglFile.getFileName() + "%");
        }
        if (StringUtils.isNotBlank(daglFile.getUseWay())) {
            querySql.append("   and t.useWay = ?");
            para.add(daglFile.getUseWay());
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("1")) {//待借阅
            querySql.append("   and t.isBorrow = '是' and t.shouldReturnDate is null");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("2")) {//待归还
            querySql.append("   and t.returnDate is null and shouldReturnDate>= '" + creDate + "'");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("3")) {//按时还
            querySql.append("   and to_date(t.returnDate,'yyyy-MM-dd') <= to_date(shouldReturnDate,'yyyy-MM-dd')");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("4")) {//逾期还
            querySql.append("   and to_date(t.returnDate,'yyyy-MM-dd') > to_date(shouldReturnDate,'yyyy-MM-dd')");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("5")) {//逾期未还
            querySql.append("   and t.returnDate is null and shouldReturnDate< '" + creDate + "'");
        }
        //拼接排序语句
        if (StringUtils.isBlank(pageImpl.getSortName())) {
            querySql.append("  order by t.creTime desc ");
        } else {
            querySql.append("  order by t." + pageImpl.getSortName() + " " + pageImpl.getSortOrder() + "");
        }

        Page<DaglFile> page = daglBorrowDao.query(querySql.toString(), pageable, para.toArray());
        //草稿列表，添加操作列
        List<DaglFile> content = page.getContent();
        for (DaglFile daglFileTemp : content) {
            // if ("1".equals(daglFileTemp.getStatus()) || "5".equals(daglFileTemp.getStatus())) {//目前是：只要是没有还的就可以设置应还日期
            daglFileTemp.setCz(CommonConstants.OPTION_UPDATE);
            // }
        }

        pageImpl.setFlag("1");
        pageImpl.getData().setRows(content);
        pageImpl.getData().setTotal((int) page.getTotalElements());
        return pageImpl;
    }

    /**
     * @Auther:邴秀慧
     * @Description:借阅历史列表
     * @Date:2018/11/15 18:00
     */
    @Override
    public PageImpl getRestitutionList(Pageable pageable, PageImpl pageImpl, DaglFile daglFile) throws Exception {
        String creDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        pageImpl.setFlag("0");
        StringBuilder querySql = new StringBuilder();
        List<Object> para = new ArrayList<>();
        querySql.append("	from DaglFile t ");
        querySql.append("	where t.visible = '" + CommonConstants.VISIBLE[1] + "'");
        querySql.append("	and t.fileStatus = '" + CommonConstants.VISIBLE[1] + "'");
        querySql.append("	and t.borrowUserId = '" + UserUtil.getCruUserId() + "'");
        querySql.append("	and t.returnDate is not null");
        //querySql.append("	and t.isBorrow = '是'");
        //querySql.append("	and t.status in ('3','4')");
        if (StringUtils.isNotBlank(daglFile.getFileCategory())) {
            querySql.append("   and t.fileCategory = ?");
            para.add(daglFile.getFileCategory());
        }
        if (StringUtils.isNotBlank(daglFile.getFileNo())) {
            querySql.append("   and t.fileNo like ?");
            para.add("%" + daglFile.getFileNo() + "%");
        }
        if (StringUtils.isNotBlank(daglFile.getFileName())) {
            querySql.append("   and t.fileName like ?");
            para.add("%" + daglFile.getFileName() + "%");
        }
        if (StringUtils.isNotBlank(daglFile.getUseWay())) {
            querySql.append("   and t.useWay = ?");
            para.add(daglFile.getUseWay());
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("1")) {//待借阅
            querySql.append("   and t.isBorrow = '是' and t.shouldReturnDate is null");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("2")) {//待归还
            querySql.append("   and t.returnDate is null and shouldReturnDate>= '" + creDate + "'");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("3")) {//按时还
            querySql.append("   and to_date(t.returnDate,'yyyy-MM-dd') <= to_date(shouldReturnDate,'yyyy-MM-dd')");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("4")) {//逾期还
            querySql.append("   and to_date(t.returnDate,'yyyy-MM-dd') > to_date(shouldReturnDate,'yyyy-MM-dd')");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("5")) {//逾期未还
            querySql.append("   and t.returnDate is null and shouldReturnDate< '" + creDate + "'");
        }
        //拼接排序语句
        if (StringUtils.isBlank(pageImpl.getSortName())) {
            querySql.append("  order by t.creTime desc");
        } else {
            querySql.append("  order by t." + pageImpl.getSortName() + " " + pageImpl.getSortOrder() + "");
        }

        Page<DaglFile> page = daglBorrowDao.query(querySql.toString(), pageable, para.toArray());
        //草稿列表，添加操作列
        List<DaglFile> content = page.getContent();
        /*for (DaglFile daglFileTemp : content) {
            // if ("1".equals(daglFileTemp.getStatus()) || "5".equals(daglFileTemp.getStatus())) {//目前是：只要是没有还的就可以设置应还日期
            daglFileTemp.setCz(CommonConstants.OPTION_UPDATE);
            // }
        }*/
        pageImpl.setFlag("1");
        pageImpl.getData().setRows(content);
        pageImpl.getData().setTotal((int) page.getTotalElements());
        return pageImpl;
    }

    /**
     * @Auther:邴秀慧
     * @Description:
     * @Date:2018/11/15 17:56
     */
    @Override
    public DaglFile saveRevert(String id) throws Exception {
        String creTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String creDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        DaglFile oldDaglFile = daglFileDao.findOne(id);
        oldDaglFile.setUpdateTime(creTime);
        oldDaglFile.setUpdateUserId(UserUtil.getCruUserId());
        oldDaglFile.setUpdateUserName(UserUtil.getCruUserName());
        //判断应还日期和当前时间确定是按时还、逾期还

/* if(StringUtils.isNotBlank(oldDaglFile.getShouldReturnDate())){
            if(creDate.compareTo(oldDaglFile.getShouldReturnDate())>0){
                oldDaglFile.setStatus("4");//逾期还
            }else{
                oldDaglFile.setStatus("3");//按时还
            }
        }*/
        oldDaglFile.setReturnDate(creDate);
        oldDaglFile.setReturnTime(creTime);

        oldDaglFile = daglFileDao.save(oldDaglFile);
        return oldDaglFile;
    }

    /**
     * @Auther:邴秀慧
     * @Description:续借回显查询数据（点击复选框打开的页面的数据）
     * @Date:2018/11/16 9:45
     */
    @Override
    public DaglBorrow renewGetdata(String ids) throws Exception {
        String[] idArr = ids.split(",");
        List<DaglFile> daglFileList = new ArrayList<DaglFile>();
        DaglBorrow daglBorrow = new DaglBorrow();
        daglFileList = daglFileDao.findByIdIn(idArr);
        if (daglFileList.size() > 0) {
            if (StringUtils.isNotBlank(daglFileList.get(0).getBorrowId())) {
                String[] borrowIdArr = daglFileList.get(0).getBorrowId().split(",");
                if (borrowIdArr.length > 0) {
                    daglBorrow = daglBorrowDao.findOne(borrowIdArr[0]);
                }

            }


        }
        daglBorrow.setFileList(daglFileList);
        return daglBorrow;
    }

    @Scheduled(cron = "0 10 0 * * ?")
    public void urgeRevert() {
        List<DaglFile> daglFileList = new ArrayList<DaglFile>();
        String creDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        String creTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        daglFileList = daglFileDao.findByShouldReturnDateAndVisibleAndReturnDateIsNull(creDate, "1");
        for (DaglFile daglFile : daglFileList) {
            //发消息
            String content = "您今天需要归还档号为：" + daglFile.getFileNo() + "的档案";
            sendMsgsByUid(daglFile.getBorrowUserId(), "档案归还提醒", content, "", creTime, null);
        }
        List<DaglFile> daglFileList1 = new ArrayList<DaglFile>();
        daglFileList1 = daglFileDao.findByVisibleAndInRenewAndReturnDateIsNotNullAndUseResultIsNull("1", "0");

        for (DaglFile daglFile : daglFileList1) {
            String messageURL = "/modules/dagl/daly/borrow/fileManage/useResultEditForm.html?id=" + daglFile.getId();
            String daibanURL = "/modules/dagl/daly/borrow/fileManage/useResultEditForm.html";
            //if (daglFile.getId().equals("4028da0767445a80016744662bea0001")) {
                String sql = "select * from sys_waitdo_noflow t where t.source_id = '" + daglFile.getId() + "'";
                //如果没有发送过代办就发送
                List<Map<String, Object>> noFlowList = jdbcTemplate.queryForList(sql);
                if (noFlowList.size() == 0) {
                    //发不走流程代办
                    SysWaitNoflow sysWaitNoflow = sendWaitNoflow(daglFile.getBorrowDeptName(), daglFile.getBorrowDeptId(), daglFile.getBorrowUserId(), daglFile.getBorrowUserName(), daglFile.getId(), "档案利用效果待办", "请填写档案利用效果", messageURL, daibanURL, "档案利用");
                }
           // }

        }
    }

    public boolean sendMsgsByUid(String userId, String subject, String content, String messageURL, String creTime, SysWaitNoflow entity) {
        boolean flag = false;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date data = new Date();
        try {
            data = format.parse(creTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        if (StringUtils.isNotBlank(userId)) {
            if (StringUtils.isNotBlank(messageURL)) {
                if (messageURL.contains("?")) {
                    messageURL = messageURL += "&workItemId=" + entity.getId();
                } else {
                    messageURL = messageURL += "?workItemId=" + entity.getId();
                }
            }
            if (ConfigConsts.SERVICE_TYPE.equals(ConfigConsts.DUBBO_TYPE)) {
                NotityMessage message = new NotityMessage();
                message.setSenderId(ConfigConsts.SYSTEM_ID);//系统id
                message.setSubject(subject);//标题
                message.setContent(content);//内容
                message.setSendTime(data);//发送时间
                message.setAcceptTime(data);//接收时间
                message.setAccepterId(userId);//接收人id
                message.setStatus("0");//状态
                message.setType("3");//类型  1手机    2邮箱   3栈内
                message.setMsgUrl(messageURL);//消息链接
                NotityService notityService = (NotityService) SpringBeanUtils.getBean("notityService");
                notityService.add(message);
                flag = true;
            } else {
                String param = "sendType=3&sendContent=" + content + "&uids=" + userId + "&subId=" + ConfigConsts.SYSTEM_ID +
                        "&msgUrl=" + messageURL + "&title=" + subject + "&appSecret=af2fff3bda2043a991018689848793b4";
                HttpRequestUtil.sendGet(ConfigConsts.MESSAGE_SERVICE_ROOT_URL + "/sendMsgsByUid", param);
                flag = true;
            }
        }
        return flag;
    }

    /**
     * @Auther:邴秀慧
     * @Description:发送不走流程待办
     * @Date:2018/11/17 12:00
     */
    public SysWaitNoflow sendWaitNoflow(String deptName, String deptId, String userId, String userName, String id, String subject, String content, String messageURL, String daibanURL, String opName) {
        SysWaitNoflow sysWaitNoflow = new SysWaitNoflow();
        //if (StringUtils.isNotBlank(UserUtil.getCruDeptId())) {
        SysWaitNoflow waitNoflw = new SysWaitNoflow();
        waitNoflw.setDraftUserName("档案系统");
        waitNoflw.setReceiveDeptName(deptName);//接收人部门
        waitNoflw.setReceiveDeptId(deptId);//接收人部门id 必填
        waitNoflw.setReceiveUserId(userId);//接受人id
        waitNoflw.setReceiveUserName(userName);//接受人name
        //waitNoflw.setRolesNo("");//接受业务角色
        waitNoflw.setOpName(opName);//操作类型
        waitNoflw.setDaibanUrl(daibanURL);//待办url  必填
        waitNoflw.setTitle(subject);//待办显示标题
        waitNoflw.setTableId("");//业务表id
        waitNoflw.setTableName("dagl_file");//业务表名
        waitNoflw.setSourceId(id);//业务id
        waitNoflw.setAttr1("");//预留字段1
        waitNoflw.setAttr2("");//预留字段2
        waitNoflw.setAttr3("");//预留字段3
        sysWaitNoflow = sysWatiNoflowService.saveWaitNoflowSystem(waitNoflw, subject, content, messageURL);
        // }
        return sysWaitNoflow;
    }

    /**
     * @Auther:邴秀慧
     * @Description:保存利用效果
     * @Date:2018/11/17 14:55
     */
    @Override
    public DaglFile saveUseResult(DaglFile daglFile) throws Exception {
        String creTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        DaglFile oldDaglFile = daglFileDao.findOne(daglFile.getId());
        oldDaglFile.setUpdateTime(creTime);
        oldDaglFile.setUpdateUserId(UserUtil.getCruUserId());
        oldDaglFile.setUpdateUserName(UserUtil.getCruUserName());
        oldDaglFile.setUseResult(daglFile.getUseResult());
        daglFile = daglFileDao.save(oldDaglFile);
        return daglFile;
    }

    /**
     * @Auther:邴秀慧
     * @Description:
     * @Date:2018/11/23 16:13
     */
    @Override
    public PageImpl getChuInBorrowList(Pageable pageable, PageImpl pageImpl, DaglFile daglFile) throws Exception {
        String creDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        pageImpl.setFlag("0");
        StringBuilder querySql = new StringBuilder();
        List<Object> para = new ArrayList<>();

        querySql.append("	from DaglFile t ");
        querySql.append("	where t.visible = '" + CommonConstants.VISIBLE[1] + "'");
        //querySql.append("	and t.isBorrow = '是'");
        //querySql.append("	and t.status in ('2','5')");
        querySql.append("	and t.fileStatus = '" + CommonConstants.VISIBLE[1] + "'");
        querySql.append("	and t.creUserId = '" + UserUtil.getCruUserId() + "'");
        //querySql.append("	and t.borrowUserId != '" + UserUtil.getCruUserId() + "'");
        querySql.append("	and t.unitId = t.belongUnitId");//本单位的数据
        querySql.append("	and t.shouldReturnDate is not null");
        querySql.append("	and t.returnDate is  null");
        if (StringUtils.isNotBlank(daglFile.getFileNo())) {
            querySql.append("   and t.fileNo like ?");
            para.add("%" + daglFile.getFileNo() + "%");
        }
        if (StringUtils.isNotBlank(daglFile.getFileName())) {
            querySql.append("   and t.fileName like ?");
            para.add("%" + daglFile.getFileName() + "%");
        }
        if (StringUtils.isNotBlank(daglFile.getUseWay())) {
            querySql.append("   and t.useWay = ?");
            para.add(daglFile.getUseWay());
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("1")) {//待借阅
            querySql.append("   and t.isBorrow = '是' and t.shouldReturnDate is null");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("2")) {//待归还
            querySql.append("   and t.returnDate is null and shouldReturnDate>= '" + creDate + "'");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("3")) {//按时还
            querySql.append("   and to_date(t.returnDate,'yyyy-MM-dd') <= to_date(shouldReturnDate,'yyyy-MM-dd')");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("4")) {//逾期还
            querySql.append("   and to_date(t.returnDate,'yyyy-MM-dd') > to_date(shouldReturnDate,'yyyy-MM-dd')");
        }
        if (StringUtils.isNotBlank(daglFile.getStatus()) && daglFile.getStatus().equals("5")) {//逾期未还
            querySql.append("   and t.returnDate is null and shouldReturnDate< '" + creDate + "'");
        }
        //拼接排序语句
        if (StringUtils.isBlank(pageImpl.getSortName())) {
            querySql.append("  order by t.creTime desc ");
        } else {
            querySql.append("  order by t." + pageImpl.getSortName() + " " + pageImpl.getSortOrder() + "");
        }

        Page<DaglFile> page = daglBorrowDao.query(querySql.toString(), pageable, para.toArray());
        //草稿列表，添加操作列
        List<DaglFile> content = page.getContent();
        for (DaglFile daglFileTemp : content) {
            // if ("1".equals(daglFileTemp.getStatus()) || "5".equals(daglFileTemp.getStatus())) {//目前是：只要是没有还的就可以设置应还日期
            daglFileTemp.setCz(CommonConstants.OPTION_UPDATE);
            // }
        }

        pageImpl.setFlag("1");
        pageImpl.getData().setRows(content);
        pageImpl.getData().setTotal((int) page.getTotalElements());
        return pageImpl;
    }


}
