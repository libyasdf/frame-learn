package com.sinosoft.sinoep.modules.dagl.bmgl.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.sinosoft.sinoep.common.util.DateUtil;
import com.sinosoft.sinoep.common.util.PageImpl;
import com.sinosoft.sinoep.modules.dagl.bmgl.dao.VirtualClassDao;
import com.sinosoft.sinoep.modules.dagl.bmgl.entity.VirtualClass;
import com.sinosoft.sinoep.modules.dagl.constant.DAGLCommonConstants;
import com.sinosoft.sinoep.modules.dagl.xtpz.filenumberrule.dao.DaglCategoryTableDao;
import com.sinosoft.sinoep.modules.dagl.xtpz.filenumberrule.entity.DaglCategoryTable;
import com.sinosoft.sinoep.user.util.UserUtil;

@Service
public class BmglServiceImpl implements BmglService {
	private Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private VirtualClassDao dao;
	@Autowired
	private DaglCategoryTableDao daglCategoryTableDao;

	@Override
	public List<Map<String, Object>> dynamicFind(String tName) {
		String table_name = "";
		if (StringUtils.isNotEmpty(tName)) {
			table_name = " and t.table_name = '" + tName + "' ";
		}
		String sql = "select t.* from table_struct_description t where 1=1 " + table_name;
		List<Map<String, Object>> query = jdbcTemplate.queryForList(sql);
		return query;
	}

	@Override
	public List<Map<String, Object>> findLabel(String tName) {

		String sql = "select d.* from ( select * from tables_relation t   where t.s_table_name not like '%_dak'  start with t.m_table_name ='"+tName+"' connect by prior t.s_table_name = t.m_table_name) s,table_description d where d.table_name=s.s_table_name";
		List<Map<String,Object>> queryForList = jdbcTemplate.queryForList(sql);
		return queryForList;
	}

	@Override
	public int dynamicAdd(String jsonStr, String tName) {
		Map<String, String> parseObject = com.alibaba.fastjson.JSONObject.parseObject(jsonStr,
				new TypeReference<Map<String, String>>() {
				});
		StringBuffer key = new StringBuffer();
		StringBuffer value = new StringBuffer();
		for (Entry<String, String> entry : parseObject.entrySet()) {
			key.append(""+entry.getKey() + ",");
			value.append("'"+entry.getValue() + "',");
		}
		key.append("cre_user_id,cre_time,");
		value.append("'"+UserUtil.getCruUserId()+"',"+"'"+DateUtil.COMMON_FULL.getDateText(new Date())+"',");
		key.append("recid");
		value.append("'"+UUID.randomUUID().toString()+"'");
		String keys =key.toString();
		String values = value.toString();
		//String keys = key.substring(0,key.length() - 1);
		//String values = value.substring(0,value.length() - 1);
		String sql = "insert into " + tName + " ( " + keys + " )" + "values (" + values + ")";
		int update = jdbcTemplate.update(sql);
		return update;
	}

	@Override
	public int dynamicUpdate(String jsonStr, String tName,String key,String value) {
		Map<String, Object> findDAGLByTableNameF = findDAGLByTableNameF(tName);
		String col_nameValue="";
		String col_name = "";
		if (findDAGLByTableNameF!=null&&!findDAGLByTableNameF.isEmpty()) {
			col_name = (String) findDAGLByTableNameF.get("S_COL_NAME");
		}
		Map<String, Object> map = findById(tName, value).get(0);
		Map<String, String> parseObject = com.alibaba.fastjson.JSONObject.parseObject(jsonStr,
				new TypeReference<Map<String, String>>() {
				});
		StringBuffer set = new StringBuffer();
		for (Entry<String, String> entry : parseObject.entrySet()) {
			set.append(entry.getKey() + "= '"+entry.getValue()+"'," );
			if(col_name.equalsIgnoreCase(entry.getKey())) {
				col_nameValue=entry.getValue();
			}
		}
		String sets = set.substring(0, set.length()-1);
		String sql = "update "+tName+" set "+sets+" where "+key+" = '"+value+"'";
		int update = jdbcTemplate.update(sql);
		if (col_name.equals("")) {
			return update;
		}
		if (!map.get(col_name).equals(col_nameValue)) {//判断传来的和查出来的一样不一样
			Map<String, Object> TableName = findDAGLByTableNameF(tName);//查询是否有子级
			if (!TableName.isEmpty()) {
				Map<String, Object> findDAGLByTableNameF2 = findDAGLByTableNameF((String)TableName.get("S_TABLE_NAME"));//以查询出来的表为父级查
				if (findDAGLByTableNameF2==null||findDAGLByTableNameF2.isEmpty()) {//判断是否有子级
					List<Map<String,Object>> findChildren = findChildren((String)TableName.get("S_TABLE_NAME"), (String)TableName.get("S_COL_NAME"), (String)map.get(TableName.get("S_COL_NAME")));//查没改档案号之前的子级
					if (findChildren!=null&&!findChildren.isEmpty()) {
						for(Map<String, Object> maps:findChildren) {
							String newValue=col_nameValue+maps.get("ARCHIVE_NO").toString().substring(col_nameValue.length());//新的文件档案号
							String updateSql = "update "+(String)TableName.get("S_TABLE_NAME")+" set "+(String)TableName.get("S_COL_NAME")+" = '" +col_nameValue + "',archive_no ='"+newValue+"' where recid = '"+(String)maps.get("recid")+"'";
							int update2 = jdbcTemplate.update(updateSql);
							log.info("修改完成1是0否："+update2);
						}
					}
				}else {
					List<Map<String,Object>> findChildren = findChildren((String)TableName.get("S_TABLE_NAME"), (String)TableName.get("S_COL_NAME"), (String)map.get(TableName.get("S_COL_NAME")));
					if (findChildren!=null&&!findChildren.isEmpty()) {
						for(Map<String, Object> maps:findChildren) {
							String newValue=col_nameValue+maps.get(findDAGLByTableNameF2.get("S_COL_NAME")).toString().substring(col_nameValue.length());//新的文件档案号
							String updateSql = "update "+(String)TableName.get("S_TABLE_NAME")+" set "+(String)TableName.get("S_COL_NAME")+" = '" +col_nameValue + "',"+findDAGLByTableNameF2.get("S_COL_NAME")+" ='"+newValue+"' where recid = '"+(String)maps.get("recid")+"'";
							int update2 = jdbcTemplate.update(updateSql);
							log.info("修改完成1是0否："+update2);
							List<Map<String,Object>> findChildren2 = findChildren((String)findDAGLByTableNameF2.get("S_TABLE_NAME"), (String)findDAGLByTableNameF2.get("S_COL_NAME"), (String)maps.get(findDAGLByTableNameF2.get("S_COL_NAME")));//子表下的子表
							if (findChildren2!=null&&!findChildren2.isEmpty()) {
								for(Map<String, Object> maps2:findChildren2) {
									String newValue2=col_nameValue+maps2.get("ARCHIVE_NO").toString().substring(col_nameValue.length());//新的文件档案号
									String updateSql2 = "update "+(String)findDAGLByTableNameF2.get("S_TABLE_NAME")+" set "+(String)findDAGLByTableNameF2.get("S_COL_NAME")+" = '" +newValue + "',archive_no ='"+newValue2+"' where recid = '"+(String)maps2.get("recid")+"'";
									int update3 = jdbcTemplate.update(updateSql2);
									log.info("修改完成1是0否："+update3);
								}
							}
						}
					}
				}

			}
		}




		return update;

	}

	@Override
	public List<Map<String, Object>> dynamicList(String tName,PageImpl pageImpl,String jsonStr,String conditions,String fids,String parameters, String complexParam,String danweihao) {
		String sortName = "";//排序名字
		String sortOrder = "";//排序方式
		String wherefid = "";// 父级ids
		String whereAnd="";//过滤树的条件
		String easyQuery="";//简单查询的条件
        String complexQuery = "";//组合查询条件
        String danwei="";//单位过滤条件
		String chushi=" and cre_chushi_id='"+UserUtil.getCruChushiId()+"'";
		String cruUserRoleNo = UserUtil.getCruUserRoleNo();
		if (cruUserRoleNo.indexOf(DAGLCommonConstants.ADMIN)>-1) {
			chushi="";
		}
		if (StringUtils.isNotEmpty(parameters)) {
			Map<String, String> where = com.alibaba.fastjson.JSONObject.parseObject(parameters,
					new TypeReference<Map<String, String>>() {
					});
			for (Entry<String, String> entry : where.entrySet()) {
				easyQuery+=" and "+entry.getKey()+" = '"+entry.getValue()+"' ";
			}
		}
		Map<String, String> parseObject = com.alibaba.fastjson.JSONObject.parseObject(conditions,
				new TypeReference<Map<String, String>>() {
				});
		for(Entry<String, String> i:parseObject.entrySet()) {
			whereAnd+=" and "+i.getKey()+"='"+i.getValue()+"' ";
		}

		if (StringUtils.isNotEmpty(pageImpl.getSortName())) {
			sortName=" order by "+pageImpl.getSortName();
			sortOrder=" "+pageImpl.getSortOrder();
		}else {
			sortName=" order by cre_time ";
			sortOrder=" desc ";
		}
		
		if (StringUtils.isNotEmpty(danweihao)) {
			String[] split = danweihao.split(",");
			danwei=" and(";
			int i = 0;
			for(String hao:split) {
				i++;
				if(i==split.length) {
					danwei=" cre_chushi_id='"+hao+"') ";
					break;
				}
				danwei=" cre_chushi_id='"+hao+"' or ";
			}
		}
		
		if (StringUtils.isNotEmpty(fids)) {
			Map<String, Object> column = findDAGLByTableName(tName);
			List<Map<String,Object>> findSublevelDedicated = findSublevelDedicated(fids, column.get("M_TABLE_NAME").toString(), column.get("S_COL_NAME").toString());
			//String[] split = fids.split(",");
			wherefid=" and(";
			int i = 0;
			for(Map<String,Object> map:findSublevelDedicated) {
				i++;
				if(i==findSublevelDedicated.size()) {
					wherefid+="("+column.get("S_COL_NAME").toString()+"='"+map.get(column.get("S_COL_NAME").toString())+"' and cre_chushi_id='"+map.get("CRE_CHUSHI_ID").toString()+"') ) ";
					break;
				}
				wherefid+="("+column.get("S_COL_NAME").toString()+"='"+map.get(column.get("S_COL_NAME").toString())+"' and cre_chushi_id='"+map.get("CRE_CHUSHI_ID").toString()+"') or ";
			}
			/*int i = 0;
			for(String fid:split) {
				Map<String, Object> TableName = findDAGLByTableName(tName);
				List<Map<String,Object>> findById = findById((String)TableName.get("M_TABLE_NAME"), fid);
				String pid = (String) findById.get(0).get(column.get("S_COL_NAME"));
				i++;
				if(split.length==i) {
					wherefid=wherefid+" "+column.get("S_COL_NAME")+" = '"+pid +"') ";
					break;
				}
				wherefid=wherefid+" "+column.get("S_COL_NAME")+" = '"+pid +"' or ";
			}*/
		}
        if (StringUtils.isNotEmpty(complexParam)) {
            complexQuery = complexSelect(complexParam);
        }
		String sql = "select * from " +tName+ " where 1=1 "+wherefid+whereAnd+danwei+chushi+easyQuery + complexQuery +sortName+ sortOrder;
		String sqlStr=sql;
		sql="select * from ( select t.*,rownum rn from ("+sql+") t where rownum <="+pageImpl.getPageNumber()*pageImpl.getPageSize()+") where rn >= "+((pageImpl.getPageNumber()-1)*pageImpl.getPageSize()+1)+" ";
		List<Map<String,Object>> queryForList = jdbcTemplate.queryForList(sql);
		if(queryForList!=null&&!queryForList.isEmpty()) {
			String totalsql = "select count(1) from " +tName+ " where 1=1 "+wherefid+whereAnd+chushi+easyQuery +danwei+complexQuery ;
			Integer queryForObject = jdbcTemplate.queryForObject(totalsql, Integer.class);
			Map<String, Object> map = new HashMap<>();
			map.put("total", queryForObject);
			map.put("sqlStr", sqlStr);
			queryForList.add(map);
		}else {
			Map<String, Object> map = new HashMap<>();
			map.put("sqlStr", sqlStr);
			queryForList.add(map);
		}
		
		
		return queryForList;
	}

	@Override
	public List<VirtualClass> findTree() {
		List<DaglCategoryTable> doorList = daglCategoryTableDao.DoorList();
		List<VirtualClass> findTree = dao.findTree();
		List<VirtualClass> list = new ArrayList<>();
		for (DaglCategoryTable categoryTable : doorList) {
			VirtualClass class1 = new VirtualClass();
			class1.setName(categoryTable.getCategoryName());
			class1.setpId("");
			class1.setId(categoryTable.getCategoryCode());
			class1.setCategoryCode(categoryTable.getCategoryCode());
			list.add(class1);
		}
		list.addAll(findTree);

		return list;
	}

	@Override
	public int replace(String tName, String fids, String column, String value1, String value2) {
		String wherefid="";
		if (StringUtils.isNotEmpty(fids)) {
			String[] split = fids.split(",");
			wherefid=" and(";
			int i = 0;
			for(String fid:split) {
				i++;
				if(split.length==i) {
					wherefid=wherefid+"recid = '"+fid +"' ) ";
					break;
				}
				wherefid=wherefid+"recid = '"+fid +"' or ";
			}
		}
		String sql="select * from "+tName+" where 1=1" + wherefid + "and " + column +" like '%"+value1+"%'";
		List<Map<String,Object>> queryForList = jdbcTemplate.queryForList(sql);
		int i=0;
		for(Map<String,Object> map:queryForList) {
			String string1 =  map.get(column).toString();
			String replaceAll = string1.replaceAll(value1, value2);
			String esql = " update "+tName+ " set "+column+"='"+replaceAll+"' where recid='"+map.get("recid")+"'";
		int update = jdbcTemplate.update(esql);
		i+=update;
		}
		return i;
	}

	@Override
	public List<Map<String, Object>> findById(String tName, String id) {
		String sql = "select * from " + tName+" where recid='"+id+"'";
		return jdbcTemplate.queryForList(sql);
	}

	@Override
	public VirtualClass addTree(VirtualClass virtualClass) {
		virtualClass.setCreTime(DateUtil.COMMON_FULL.getDateText(new Date()));
		virtualClass.setCreUserId(UserUtil.getCruUserId());
		virtualClass.setCreUserName(UserUtil.getCruUserName());
		virtualClass.setCreJuId(UserUtil.getCruJuId());
		virtualClass.setCreJuName(UserUtil.getCruJuName());
		return dao.saveAndFlush(virtualClass);
	}

	@Override
	public int deleteTree(String id) {
		String sql = "select * from  dagl_virtual_class  start with id ='"+id +"' connect by prior id=pid";
		List<VirtualClass> query = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(VirtualClass.class));
		for(VirtualClass virtualClass:query) {
			dao.delete(virtualClass.getId());
		}
		return 1;
	}

	@Override
	public int dynamicDelete(String tName, String id) {
		String sql = "delete from "+tName+" where recid='"+id+"'";
		return jdbcTemplate.update(sql);
	}

	@Override
	public String findMenById(String category_code) {
		String sql ="select id from dagl_category_table where category_code='"+category_code+"'";
		String queryForObject = jdbcTemplate.queryForObject(sql, String.class);
		return queryForObject;
	}

	@Override
	public List<Map<String, Object>> findDHGZbyMCode(String category_code_id) {
		String sql = "select * from dagl_party_num_rule where category_id = '"+category_code_id+"' order by order_num asc";
		List<Map<String,Object>> queryForList = jdbcTemplate.queryForList(sql);
		return queryForList;
	}

	@Override
	public Map<String, Object> findDAGLByTableName(String tName) {
		String sql ="select * from tables_relation where s_table_name = '"+tName+"'";
		List<Map<String, Object>> queryForList = jdbcTemplate.queryForList(sql);
		return queryForList.get(0);
	}

	@Override
	public Map<String, Object> findDAGLByTableNameF(String tName) {
		String sql ="select * from tables_relation where m_table_name = '"+tName+"'";
		List<Map<String, Object>> queryForList = jdbcTemplate.queryForList(sql);
		if (queryForList!=null&&!queryForList.isEmpty()) {
			return queryForList.get(0);

		}else {
			return null;
		}
	}

	public List<Map<String, Object>> findChildren(String tName,String colnum,String value){
		String sql = "select  * from "+tName+" where "+colnum+" = '"+value+"'";
		List<Map<String,Object>> queryForList = jdbcTemplate.queryForList(sql);
		return queryForList;
	}

	@Override
	public String findZHbycolnum(String tName, String colnum) {
		String sql = "select COLUMN_CHN_NAME from table_struct_description where table_name='"+tName+"' and COLUMN_NAME ='"+colnum+"'";
		return jdbcTemplate.queryForObject(sql, String.class);
	}

	@Override
	public List<Map<String, Object>> findLabelDAK(String tName) {
		String sql = "select d.* from ( select * from tables_relation t   where t.s_table_name  like '%_dak'  start with t.m_table_name ='"+tName+"' connect by prior t.s_table_name = t.m_table_name) s,table_description d where d.table_name=s.s_table_name";
		List<Map<String,Object>> queryForList = jdbcTemplate.queryForList(sql);
		return queryForList;
	}

	/**
	 * TODO 查询勾选的多行数据列表
	 * @author 李颖洁
	 * @date 2018年11月22日上午11:28:10
	 * @param tName 当前页标签页的表名
	 * @param fids  勾选的ids
	 * @return
	 */
	@Override
	public List<Map<String, Object>> getSelectedData(String tName, String fids) {
		String wherefid="";
		if (StringUtils.isNotEmpty(fids)) {
			String[] split = fids.split(",");
			wherefid=" and(";
			int i = 0;
			for(String fid:split) {
				i++;
				if(split.length==i) {
					wherefid=wherefid+"recid = '"+fid +"' ) ";
					break;
				}
				wherefid=wherefid+"recid = '"+fid +"' or ";
			}
		}
		String sql="select * from "+tName+" where 1=1" + wherefid ;
		log.info(sql);
		List<Map<String,Object>> queryForList = jdbcTemplate.queryForList(sql);
		return queryForList;
	}

	/**
	 * TODO 获取未组卷的文件
	 * @author 李颖洁
	 * @date 2018年11月22日下午1:55:45
	 * @param tName 表名
	 * @return List<Map<String, Object>>
	 */
	@Override
	public List<Map<String, Object>> getNotSetVolumeList(String tName,String basefolderUnit) {
		//获取子表表名
		List<Map<String,Object>> list = findLabel(tName);
		if(list.size()>0){
			String name = (String) list.get(0).get("TABLE_NAME");
			String sql = "select * from "+name+" where archive_flag = 02" ;
			//获取角色
			//String role = UserUtil.getCruUserRoleNo();
			String condition = "	and cre_chushi_id = "+basefolderUnit;
			sql += condition;
			log.info(sql);
			list = jdbcTemplate.queryForList(sql);
		}
		return list;
	}

	/**
	 * TODO 根据父表id 查询子表的关联信息
	 * @author 李颖洁
	 * @date 2018年11月23日上午11:54:37
	 * @param tName 
	 * @param fid
	 * @return
	 */
	@Override
	public List<Map<String, Object>> getChildDataByFartherId(String tName, String fid,String basefolderUnit) {
		//获取子表表名
		List<Map<String,Object>> list = findLabel(tName);
		//获取子表关联字段
		Map<String,Object> conColMap = findDAGLByTableNameF(tName);
		String conCol = "";
		if (conColMap!=null&&!conColMap.isEmpty()) {
			conCol = (String) conColMap.get("S_COL_NAME");
		}
		if(list.size()>0){
			String name = (String) list.get(0).get("TABLE_NAME");
			String sql = "select * from "+name+" where "+conCol+"='"+fid+"' and cre_chushi_id = "+basefolderUnit+" order by piece_no asc" ;
			list = jdbcTemplate.queryForList(sql);
		}
		return list;
	}

	/**
	 * TODO 拆卷
	 * @author 李颖洁
	 * @date 2018年11月23日下午4:15:04
	 * @param tName
	 * @param ids
	 * @param archiveFlag
	 * @param conCol
	 * @return
	 */
	@Override
	public int openVolume(String tName, String ids, String archiveFlag, String conCol,String conVal) {
		String sql = "UPDATE "+tName+" SET "+conCol+" = '"+conVal+"',ARCHIVE_FLAG = '"+archiveFlag+"' WHERE RECID IN ("+ids+")";
		log.info(sql);
		int num = jdbcTemplate.update(sql);
		return num;
	}

	/**
	 * TODO 更改卷内文件关联（档案确认调整）
	 * @author 李颖洁
	 * @date 2018年11月24日下午6:08:39
	 * @param tName 卷内表名
	 * @param conCol 关联字段
	 * @param conVal 关联字段值
	 * @param data 更改数据项
	 * @return int
	 */
	@Override
	public int updateFileRelation(String tName, String conCol, String conVal, String data,String categoryCode) {
		int num;
		String categoryId = findMenById(categoryCode);
		List<Map<String,Object>> list = findDHGZbyMCode(categoryId);
		int len = list.size();
		String numbLength = (String)list.get(len-1).get("NUMB_LENGTH");
		int columLen = 0;
		if(!StringUtils.isBlank(numbLength)){
			columLen = Integer.parseInt(numbLength);
		}
		String connector = (String) list.get(len-2).get("CONNECTOR");
		String pieceNo;
		String archiveNo;
		try {
			JSONArray arr = JSON.parseArray(data);
			String[] sql = new String[arr.size()];
			for (int i=0;i<arr.size();i++) {
				archiveNo = "";
				Map<String, String> parseObject = com.alibaba.fastjson.JSONObject.parseObject(JSON.toJSONString(arr.get(i)),
						new TypeReference<Map<String, String>>() {
				});
				pieceNo = parseObject.get("PIECE_NO");
				if(columLen>0){
					if(pieceNo.length()>columLen){
						pieceNo = pieceNo.substring(0,columLen);
					}else if(pieceNo.length()<columLen){
						for(int j=0;j<columLen-pieceNo.length();j++){
							pieceNo = "0"+pieceNo;
						}
					}
				}
				if(!StringUtils.isBlank(connector)){
					archiveNo = conVal+connector+pieceNo;
				}else{
					archiveNo = conVal+pieceNo;
				}
				sql[i] = "UPDATE "+tName+" SET PIECE_NO = "+pieceNo+",ARCHIVE_NO = "+archiveNo+","
						+conCol+"="+conVal+" WHERE RECID='"+parseObject.get("RECID")+"'";
				log.info(sql[i]);
			}
			int[] batchUpdate = jdbcTemplate.batchUpdate(sql);
			if(batchUpdate.length==arr.size()){
				return num = 1;
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			return num=0;
		}

		return num = 0;
	}

	/**
	 * @Author 王富康
	 * @Description //TODO 档案提交
	 * @Date 2018/11/22 19:36
	 * @Param [tName, fids]
	 * @return java.util.List<java.util.Map<java.lang.String,java.lang.Object>>
	 **/
	@Override
	public List<Map<String, Object>> recordSubmit(String tName, String fids) {
		List<Map<String,Object>> queryForList = getSelectedData(tName,fids);//查询勾选的多行数据列表
		List<Map<String,Object>> successList =new ArrayList<>();//成功的数据
		List<Map<String,Object>> alreadySubmmitList = new ArrayList<>();//已经提交待审核的数据
		List<Map<String,Object>> P_NotSubmmitList = new ArrayList<>();//父表为移交的数据
		List<Map<String,Object>> NotAssociatedList = new ArrayList<>();//有父级，尚未关联的

		for(int i = 0;i < queryForList.size();i++){
			//遍历勾选的数据
			//首先查看勾选的数据是否是已移交待审核状态
			Map<String,Object> map = queryForList.get(i);
			String archive_entity_status = String.valueOf(map.get("ARCHIVE_ENTITY_STATUS"));//防止空指针，如果为空，返回null
			if(DAGLCommonConstants.ARCHIVE_ENTITY_STATUS[1].equals(archive_entity_status)||DAGLCommonConstants.ARCHIVE_ENTITY_STATUS[2].equals(archive_entity_status)){
				//如果数据是已移交待审核状态或者已移交，放到错误List中，不可提交
				alreadySubmmitList.add(map);
				continue;
			}else{//01或者null
				String pTableSql =
						"SELECT t.*\n" +
								"  FROM tables_relation t, table_description s\n" +
								" WHERE t.m_table_name = s.table_name\n" +
								"   and t.s_table_name = '"+tName+"'";//排除父节点为门类的数据

				List<Map<String,Object>> pTableList = jdbcTemplate.queryForList(pTableSql);
				if(pTableList.size()>0){
					//有父表，查询出父表的状态
					Map<String,Object> relationMap = pTableList.get(0);
					String pTableName = String.valueOf(relationMap.get("M_TABLE_NAME"));//父表id
					String mColName = String.valueOf(relationMap.get("M_COL_NAME"));//父表字段
					String sColName = String.valueOf(relationMap.get("S_COL_NAME"));//子表字段
					String sColData = String.valueOf(map.get(sColName));
					String archiveFlag = String.valueOf(map.get("ARCHIVE_FLAG"));
					if(DAGLCommonConstants.ARCHIVE_FLAG[0].equals(archiveFlag)){
						//已组卷
						//与父表做了关联,查询出父表的那条数据
						String sql = "SELECT t.* FROM "+pTableName+" t WHERE t."+mColName+" = '"+sColData+"'";
						List<Map<String,Object>> pTableDataList = jdbcTemplate.queryForList(sql);
						if(pTableDataList.size()>0){//常理来说是不应该为空的，这里做判断是为了防止垃圾数据导致报错

							Map<String,Object> pTableDataMap = pTableDataList.get(0);
							//父表的档案实体状态
							String P_archive_entity_status = String.valueOf(pTableDataMap.get("ARCHIVE_ENTITY_STATUS"));
							if(DAGLCommonConstants.ARCHIVE_ENTITY_STATUS[1].equals(P_archive_entity_status)||DAGLCommonConstants.ARCHIVE_ENTITY_STATUS[2].equals(P_archive_entity_status)){
								//父表状态为已移交待归档，或者以移交，则证明为补录，更新其状态为已移交待审
								//更新选中的档案的移交状态
								updateArchiveEntityStatus(tName,map);

								successList.add(map);

							}else{//01或者null
								//证明父节点未移交，状态为已归档，放到错误的List中返回前台
								P_NotSubmmitList.add(map);
								continue;
							}
						}

					}else{//未关联状态一律视为为组卷
						//未组卷
						NotAssociatedList.add(map);
						continue;
					}
				}else{
					//没有父表，更新状态
					//父表状态为已移交待归档，或者以移交，则证明为补录，更新其状态为已移交待审
					//更新选中的档案的移交状态
					updateArchiveEntityStatus(tName,map);
					successList.add(map);
				}
			}
		}
		Map<String,Object> zongMap = new HashMap<String,Object>();
		zongMap.put("successList",successList);
		zongMap.put("alreadySubmmitList",alreadySubmmitList);
		zongMap.put("P_NotSubmmitList",P_NotSubmmitList);//NotAssociatedList
		zongMap.put("NotAssociatedList",NotAssociatedList);
		List<Map<String,Object>> zongList = new ArrayList();
		zongList.add(zongMap);
		return zongList;
	}

	/**
	 * @Author 王富康
	 * @Description //TODO 跟新档案及其子表移交状态。
	 * @Date 2018/11/24 9:40
	 * @Param []
	 * @return void
	 **/
	public void updateArchiveEntityStatus(String tName,Map<String,Object> map){

		String updateStatusSql = "update "+tName+" t set t.archive_entity_status='"+DAGLCommonConstants.ARCHIVE_ENTITY_STATUS[1]+"' where t.recid ='"+String.valueOf(map.get("RECID"))+"'";//更新状态的sql

		int updateSum =  jdbcTemplate.update(updateStatusSql);

		//如果有子表数据，同时更新所有子表表名
		String sTableSql =  "	select s.*\n" +
				"  		from tables_relation s\n" +
				" 		start with s.m_table_name = '"+tName+"'\n" +
				"		connect by prior s.s_table_name = s.m_table_name\n" +
				" 	order by rownum desc";

		List<Map<String,Object>> sTableList = jdbcTemplate.queryForList(sTableSql);//得到子表及关联的信息

		if(sTableList.size()>0){
			for(int j= 0;j<sTableList.size();j++){//目前只更新前两层的数据
				Map<String,Object> sTableRelationMap = sTableList.get(j);
				//更新所有子表的状态
				String sTableName = String.valueOf(sTableRelationMap.get("S_TABLE_NAME"));//子表id
				String PColnumName = String.valueOf(sTableRelationMap.get("M_COL_NAME"));//父表关联字段
				String sColnumName = String.valueOf(sTableRelationMap.get("S_COL_NAME"));//子表关联字段

				String PColnumValue = String.valueOf(map.get(PColnumName));//父表的值字段
				//查询子表的数据
				if(j==0){
					//此时操作的是子表状态
					List<Map<String, Object>> sData = findChildren(sTableName,sColnumName,PColnumValue);
					for(int m = 0;m<sData.size();m++){
						Map<String,Object> sTableDataMap = sData.get(m);
						//更新子表的数据
						String sTablerelationData = String.valueOf(sTableDataMap.get("RECID"));//子表id
						String updateSTableStatusSql = "update "+sTableName+" t set t.archive_entity_status='"+DAGLCommonConstants.ARCHIVE_ENTITY_STATUS[1]+"' where t.recid='"+sTablerelationData+"'";//更新子表状态的sql
						int updateSTableSum =  jdbcTemplate.update(updateSTableStatusSql);

					}
				}else if(j == 1){
					//得到子表的数据
					List<Map<String, Object>> sData = findChildren(sTableName,sColnumName,PColnumValue);
					for(int m = 0;m<sData.size();m++){
						Map<String,Object> sTableDataMap = sData.get(m);
						String sPColnumValue = String.valueOf(sTableDataMap.get(PColnumName));//父表的值字段
						//孙子级数据
						List<Map<String, Object>> ssData = findChildren(sTableName,sColnumName,sPColnumValue);
						for(int n = 0;n<ssData.size();n++){
							//更新孙子表的数据
							String sTablerelationData = String.valueOf(sTableDataMap.get("RECID"));//子表id
							String updateSTableStatusSql = "update "+sTableName+" t set t.archive_entity_status='"+DAGLCommonConstants.ARCHIVE_ENTITY_STATUS[1]+"' where t.recid='"+sTablerelationData+"'";//更新子表状态的sql
							int updateSTableSum =  jdbcTemplate.update(updateSTableStatusSql);
						}
					}
				}

			}
		}
	}

    /**
     * @Auther:邴秀慧
     * @Description:组合查询
     * @Date:2018/11/26 9:49
     */
    private String complexSelect(String complexParam) {
        Map<String, String> ConnectMap = new HashMap<String, String>() {{
            put("01", " and ");
            put("02", " or ");
        }};
        Map<String, String> ConditionMap = new HashMap<String, String>() {{
            put("01", " like ");
            put("02", " > ");
            put("03", " < ");
            put("04", " = ");
        }};
        String complexSelect = "";
        JSONObject jsStr = JSONObject.parseObject(complexParam);
        JSONArray selectConnectArray = (JSONArray) jsStr.get("selectConnectArray");
        JSONArray selectNameArray = (JSONArray) jsStr.get("selectNameArray");
        JSONArray selectConditionArray = (JSONArray) jsStr.get("selectConditionArray");
        JSONArray inputValueArray = (JSONArray) jsStr.get("inputValueArray");
        for (int i = 0; i < selectNameArray.size(); i++) {
            if (selectNameArray.get(i) != null && !selectNameArray.get(i).toString().equals("")) {
                if(inputValueArray.get(i) != null && !inputValueArray.get(i).toString().equals("")){
                    complexSelect += ConnectMap.get(selectConnectArray.get(i).toString());
                    complexSelect += selectNameArray.get(i);
                    complexSelect += ConditionMap.get(selectConditionArray.get(i).toString());
                    if (ConditionMap.get(selectConditionArray.get(i).toString()).equals(" like ")) {
                        complexSelect += " '%" + inputValueArray.get(i).toString() + "%'";
                    } else {
                        complexSelect += " '" + inputValueArray.get(i).toString() + "'";
                    }
                }else{
                    if (selectNameArray.get(i).toString().equals("barcode") && inputValueArray.get(i).toString().equals("")) {//条形码
                        complexSelect += ConnectMap.get(selectConnectArray.get(i).toString());
                        complexSelect += selectNameArray.get(i);
                        complexSelect += " is null";
                    }
                }
            }
        }
        return complexSelect;
    }

	@Override
	public int isRepetition(String column,String relevancyId, String tName, String chushiId) {
		String chushi="";
		if(StringUtils.isNotEmpty(chushiId)) {
			chushi=" and cre_chushi_id='"+chushiId+"' ";
		}
		String sql = "select count(1) from "+tName+" where "+column+"='"+relevancyId+"'"+chushi;
		Integer queryForObject = jdbcTemplate.queryForObject(sql, Integer.class);
		return queryForObject;
	}

	/**
	 * 
	 * @param fids
	 * @return
	 * @author 颜振兴
	 * list<Map<String,Object>>
	 * TODO 列表查询子级专用 别人用不上也不要用
	 */
	public List<Map<String,Object>> findSublevelDedicated(String fids,String tName,String column) {
		String[] split = fids.split(",");
		StringBuffer buffer = new StringBuffer("(");
		int i = 0;
		for(String id:split) {
			i++;
			if(i==split.length) {
				buffer.append("'"+id+"')");
				break;
			}
			buffer.append("'"+id+"',");
		}
		String sql = "select "+column+",cre_chushi_id  from "+tName+" where recid in "+buffer.toString()+"";
		List<Map<String,Object>> queryForList = jdbcTemplate.queryForList(sql);
		return queryForList;
	}

	@Override
	public Map<String, Object> findParentData(String tName, String fids) {
		String tableName="M_TABLE_NAME";
		if(StringUtils.isBlank(fids)) {
			 tableName="S_TABLE_NAME";
		}
		String id = fids.split(",")[0];
		Map<String, Object> findDAGLByTableName = findDAGLByTableName(tName);
		List<Map<String,Object>> findById = findById(findDAGLByTableName.get(tableName).toString(), id);
		if (findById!=null&&!findById.isEmpty()) {
			return findById.get(0);
		}else {
			return null;
		}
	}

	@Override
	public int dynamicDeletes(String tName, String ids) {
		String[] split = ids.split(",");
		int i = 0;
		for(String id : split) {
			int dynamicDelete = dynamicDelete(tName, id);
			i+=dynamicDelete;
		}
		return i;
	}

	@Override
	public int findThisTotal(String tName, String chushiid) {
		String sql = "select count(1) from "+tName+" where cre_chushi_id = '"+chushiid+"'";
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

}
