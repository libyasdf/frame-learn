package com.sinosoft.sinoep.modules.dagl.bmgl.dao;

import com.sinosoft.sinoep.common.jpa.repository.BaseRepository;
import com.sinosoft.sinoep.modules.dagl.bmgl.entity.VirtualClass;

public interface VirtualClassDao extends BaseRepository<VirtualClass, String> ,VirtualClassRepository {

}
