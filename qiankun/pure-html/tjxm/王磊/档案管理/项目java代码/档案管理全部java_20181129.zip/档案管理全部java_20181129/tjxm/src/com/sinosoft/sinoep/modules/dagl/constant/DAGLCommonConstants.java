package com.sinosoft.sinoep.modules.dagl.constant;


/**
 * 档案管理常量类
 * @author 王磊
 * @Date 2018年11月23日
 */
public class DAGLCommonConstants {
	
	/** 处室档案管理员业务角色编号 */
    public static final String CHU_SHI_ADMIN = "D701";
    
    /** 档案馆管理理员业务角色编号 */
    public static final String ADMIN = "D702";
    
    /** 文电管理文件状态：待归档、已归档 */
    public static final String WEN_DIAN_STATUS[] = {"待归档","已归档"};
    
    /** 文电管理文件类型：需归档、留存、销毁 */
    public static final String WEN_DIAN_TYPE[] = {"01","02","03"};

    /**  档案移交状态 */
    public static final String ARCHIVE_ENTITY_STATUS[] = {"已归档","已移交待审核","已移交"};

    /**  档案组卷状态*/
    public static final String ARCHIVE_FLAG[] ={"已组卷","未组卷"};
}
