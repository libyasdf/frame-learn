package com.sinosoft.sinoep.modules.dagl.xtpz.datacontrast.dao;

import com.sinosoft.sinoep.common.jpa.repository.BaseRepository;
import com.sinosoft.sinoep.modules.dagl.xtpz.datacontrast.entity.ContrastingRelations;

public interface ContrastDao extends BaseRepository<ContrastingRelations, String> {
}
