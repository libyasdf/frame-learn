package com.sinosoft.sinoep.modules.dagl.daly.borrow.controller;

import com.sinosoft.sinoep.common.util.PageImpl;
import com.sinosoft.sinoep.handlerInterceptor.LogAnnotation;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.dao.DaglFileDao;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.entity.DaglBorrow;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.entity.DaglFile;
import com.sinosoft.sinoep.modules.dagl.daly.borrow.services.DaglBorrowService;
import com.sinosoft.sinoep.user.util.UserUtil;
import com.sinosoft.sinoep.waitNoflow.services.SysWaitNoflowService;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @Auther:邴秀慧
 * @Description:借阅本单位档案控制层
 * @Date:2018/11/10 9:52
 */
@Controller
@RequestMapping("/dagl/daly/borrow")
public class DaglBorrowController {

    private Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private DaglBorrowService daglBorrowService;

    @Autowired
    private DaglFileDao daglFileDao;

    @Autowired
    private SysWaitNoflowService sysWatiNoflowService;

    /**
     * @Auther:邴秀慧
     * @Description:草稿列表查询
     * @Date:2018/11/10 9:57
     */
    @LogAnnotation(value = "query", opName = "草稿列表查询")
    @ResponseBody
    @RequestMapping("getlist")
    public PageImpl getList(PageImpl pageImpl, DaglBorrow daglBorrow) {
        try {
            Pageable pageable = new PageRequest(pageImpl.getPageNumber() - 1, pageImpl.getPageSize());
            pageImpl = daglBorrowService.getPageListDraft(pageable, pageImpl, daglBorrow);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return pageImpl;
    }

    /**
     * @Auther:邴秀慧
     * @Description: 保存主子表
     * @Date:2018/11/10 9:57
     */
    @LogAnnotation(value = "save", opName = "保存主子表")
    @ResponseBody
    @RequestMapping("saveForm")
    public JSONObject saveForm(@RequestBody DaglBorrow daglBorrow) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        try {
            daglBorrow = daglBorrowService.saveForm(daglBorrow);
            json.put("flag", "1");
            json.put("data", daglBorrow);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            json.put("msg", "");
        }
        return json;
    }

    /**
     * @Auther:邴秀慧
     * @Description:删除主表数据
     * @Date:2018/11/10 10:06
     */
    @LogAnnotation(value = "delete", opName = "删除主表数据")
    @ResponseBody
    @RequestMapping("deleteDaglBorrow")
    public JSONObject deleteDaglBorrow(String id) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        try {
            int result = daglBorrowService.deleteDaglBorrow(id);
            if (result != 0) {
                json.put("flag", "1");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return json;
    }

    /**
     * @Auther:邴秀慧
     * @Description:删除字表数据
     * @Date:2018/11/10 10:06
     */
    @LogAnnotation(value = "deleteDaglFile", opName = "删除字表数据")
    @ResponseBody
    @RequestMapping("deleteDaglFile")
    public JSONObject deleteDaglFile(String ids) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        try {
            int result = daglBorrowService.deleteDaglFile(ids);
            if (result != 0) {
                json.put("flag", "1");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return json;
    }

    /**
     * @Auther:邴秀慧
     * @Description:根据ID获取主子表的数据
     * @Date:2018/11/10 11:08
     */
    @LogAnnotation(value = "edit", opName = "根据ID获取主子表的数据")
    @ResponseBody
    @RequestMapping("edit")
    public JSONObject edit(String id) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        DaglBorrow daglBorrow = null;
        try {
            daglBorrow = daglBorrowService.getById(id);
            if(UserUtil.getCruUserRoleNo().indexOf("D701")>=0){//是否是处档案管理员
                daglBorrow.setIsChuAdmin("1");
            }
            json.put("flag", "1");
            json.put("data", daglBorrow);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return json;
    }

    /**
     * @Auther:邴秀慧
     * @Description:
     * @Date:2018/11/17 14:27
     */
    @LogAnnotation(value = "query", opName = "档案馆列表查询")
    @ResponseBody
    @RequestMapping("getAllFileList")
    public PageImpl getAllFileList(PageImpl pageImpl, DaglFile daglFile) {
        try {
            Pageable pageable = new PageRequest(pageImpl.getPageNumber() - 1, pageImpl.getPageSize());
            pageImpl = daglBorrowService.getAllFileList(pageable, pageImpl, daglFile);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return pageImpl;
    }

    /**
     * @Auther:邴秀慧
     * @Description:
     * @Date:2018/11/17 14:27
     */
    @LogAnnotation(value = "update", opName = "修改流程状态")
    @ResponseBody
    @RequestMapping("updateFlag")
    public JSONObject updateFlag(String id, String subflag) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        try {
            daglBorrowService.updateSubFlag(id, subflag);
            json.put("flag", "1");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return json;
    }

    /**
     * @Auther:邴秀慧
     * @Description:根据ID获取主子表的数据
     * @Date:2018/11/10 11:08
     */
    @LogAnnotation(value = "edit", opName = "根据ID获取主子表的数据")
    @ResponseBody
    @RequestMapping("fileEdit")
    public JSONObject fileEdit(String id) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        DaglFile daglFile = null;
        try {
            daglFile = daglBorrowService.fileEdit(id);
            json.put("flag", "1");
            json.put("data", daglFile);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return json;
    }

    /**
     * @Auther:邴秀慧
     * @Description:保存应还日期
     * @Date:2018/11/15 11:18
     */
    @LogAnnotation(value = "saveReturnDate", opName = "保存应还日期")
    @ResponseBody
    @RequestMapping("saveReturnDate")
    public JSONObject saveReturnDate(DaglFile daglFile) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        if(StringUtils.isNotBlank(daglFile.getId())) {
            try {
                daglFile = daglBorrowService.saveReturnDate(daglFile);
                json.put("flag", "1");
                json.put("data", daglFile);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                json.put("msg", "");
            }
        }
        return json;
    }

    /**
     * @Auther:邴秀慧
     * @Description:正在借阅列表
     * @Date:2018/11/15 15:33
     */
    @LogAnnotation(value = "query", opName = "正在借阅列表")
    @ResponseBody
    @RequestMapping("getInBorrowList")
    public PageImpl getInBorrowList(PageImpl pageImpl, DaglFile daglFile) {
        try {
            Pageable pageable = new PageRequest(pageImpl.getPageNumber() - 1, pageImpl.getPageSize());
            pageImpl = daglBorrowService.getInBorrowList(pageable, pageImpl, daglFile);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return pageImpl;
    }

    /**
     * @Auther:邴秀慧
     * @Description:借阅历史列表
     * @Date:2018/11/15 15:33
     */
    @LogAnnotation(value = "query", opName = "借阅历史列表")
    @ResponseBody
    @RequestMapping("getRestitutionList")
    public PageImpl getRestitutionList(PageImpl pageImpl, DaglFile daglFile) {
        try {
            Pageable pageable = new PageRequest(pageImpl.getPageNumber() - 1, pageImpl.getPageSize());
            pageImpl = daglBorrowService.getRestitutionList(pageable, pageImpl, daglFile);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return pageImpl;
    }

    /**
     * @Auther:邴秀慧
     * @Description:保存应还日期
     * @Date:2018/11/15 11:18
     */
    @LogAnnotation(value = "saveRevert", opName = "保存应还日期")
    @ResponseBody
    @RequestMapping("saveRevert")
    public JSONObject saveRevert(String id) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        DaglFile daglFile = new DaglFile();
        if(StringUtils.isNotBlank(id)) {
            try {
                daglFile = daglBorrowService.saveRevert(id);
                json.put("flag", "1");
                //json.put("data", daglFile);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                json.put("msg", "");
            }
        }
        return json;
    }

    @LogAnnotation(value = "edit", opName = "续借回显查询数据")
    @ResponseBody
    @RequestMapping("renewGetdata")
    public JSONObject renewGetdata(String ids) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        DaglBorrow daglBorrow = null;
        try {
            daglBorrow = daglBorrowService.renewGetdata(ids);
            json.put("flag", "1");
            json.put("data", daglBorrow);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return json;
    }

    /**
     * @Auther:邴秀慧
     * @Description:催还
     * @Date:2018/11/15 11:18
     */
    @LogAnnotation(value = "sendUrge", opName = "催还")
    @ResponseBody
    @RequestMapping("sendUrge")
    public JSONObject sendUrge(String userId,String id) {
        String creTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        DaglFile daglFile = new DaglFile();
        daglFile = daglFileDao.findOne(id);
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        if(StringUtils.isNotBlank(daglFile.getId())) {
            try {
                String content = "您借阅的档号为：" + daglFile.getFileNo() + "的档案已超期，请尽快归还！";
                daglBorrowService.sendMsgsByUid(daglFile.getBorrowUserId(), "档案归还提醒", content, "", creTime, null);
                json.put("flag", "1");
                json.put("data", daglFile);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                json.put("msg", "");
            }
        }
        return json;
    }


    @LogAnnotation(value = "saveUseResult", opName = "保存利用效果")
    @ResponseBody
    @RequestMapping("saveUseResult")
    public JSONObject saveUseResult(DaglFile daglFile) {
        JSONObject json = new JSONObject();
        json.put("flag", "0");
        if(StringUtils.isNotBlank(daglFile.getId())) {
            try {
                daglFile = daglBorrowService.saveUseResult(daglFile);
                //根据业务表id删除待办
                sysWatiNoflowService.deleteWaitNoflow("",daglFile.getId(),"","","");
                json.put("flag", "1");
                json.put("data", daglFile);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
                json.put("msg", "");
            }
        }
        return json;
    }


    /**
     * @Auther:邴秀慧
     * @Description:正在借阅列表
     * @Date:2018/11/15 15:33
     */
    @LogAnnotation(value = "query", opName = "正在借阅列表")
    @ResponseBody
    @RequestMapping("getChuInBorrowList")
    public PageImpl getChuInBorrowList(PageImpl pageImpl, DaglFile daglFile) {
        try {
            Pageable pageable = new PageRequest(pageImpl.getPageNumber() - 1, pageImpl.getPageSize());
            pageImpl = daglBorrowService.getChuInBorrowList(pageable, pageImpl, daglFile);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
        }
        return pageImpl;
    }
}