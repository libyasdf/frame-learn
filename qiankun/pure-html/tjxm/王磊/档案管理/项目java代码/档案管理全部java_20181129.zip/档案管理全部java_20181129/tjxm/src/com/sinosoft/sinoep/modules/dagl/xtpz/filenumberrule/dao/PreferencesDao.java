package com.sinosoft.sinoep.modules.dagl.xtpz.filenumberrule.dao;

import com.sinosoft.sinoep.common.jpa.repository.BaseRepository;
import com.sinosoft.sinoep.modules.dagl.xtpz.filenumberrule.entity.PartyNumRule;

public interface PreferencesDao extends BaseRepository<PartyNumRule, String> {
}
