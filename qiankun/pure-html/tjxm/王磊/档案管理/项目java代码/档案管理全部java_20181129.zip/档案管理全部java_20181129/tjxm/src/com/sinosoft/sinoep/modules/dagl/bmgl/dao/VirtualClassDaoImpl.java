package com.sinosoft.sinoep.modules.dagl.bmgl.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sinosoft.sinoep.modules.dagl.bmgl.entity.VirtualClass;

@Repository
public class VirtualClassDaoImpl implements VirtualClassRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<VirtualClass> findTree() {
		String sql = "select * from dagl_virtual_class" ;
		return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(VirtualClass.class));
	}
}
